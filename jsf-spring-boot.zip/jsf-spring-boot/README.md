# jsf-spring-boot
JSF 2.3 + Spring Boot 2 + hibernate + Primefaces

## Instructions
Build it with maven and run the war as if it was an standard jar:

`java -jar target/jsf-spring-boot-1.0.0.war`

It will launch a JSF and Spring powered website that you can access at http://localhost:8012/ui/login.xhtml

