package com.segmadesk.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "CUSTOMER")
public class Customer implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2084936653529766822L;
	private int id;
	private int productId;
	private String name; 
	private String description;
	private String email;
	private String customerCode;
	private Date customerAmcStartDate;
	private Date customerAmcEndDate;
	
	
	
	
	public Customer() {
		super();
	}
	public Customer(int id, int productId, String name, String description, String email, String customerCode,
			Date customerAmcStartDate, Date customerAmcEndDate) {
		super();
		this.id = id;
		this.productId = productId;
		this.name = name;
		this.description = description;
		this.email = email;
		this.customerCode = customerCode;
		this.customerAmcStartDate = customerAmcStartDate;
		this.customerAmcEndDate = customerAmcEndDate;
	}
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID", nullable = false, length = 200)
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	@Column(name = "PRODUCT_ID", nullable = false, length = 200)
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	
	@Column(name = "NAME", nullable = false, length = 200)
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	@Column(name = "DESCRIPTION", nullable = false, length = 200)
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	@Column(name = "EMAIL", nullable = false, length = 200)
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	@Column(name = "CUSTOMERCODE", nullable = false, length = 200)
	public String getCustomerCode() {
		return customerCode;
	}
	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}
	
	@Column(name = "CUSTOMER_AMC_STARTDATE", nullable = false, length = 200)
	public Date getCustomerAmcStartDate() {
		return customerAmcStartDate;
	}
	public void setCustomerAmcStartDate(Date customerAmcStartDate) {
		this.customerAmcStartDate = customerAmcStartDate;
	}
	
	@Column(name = "CUSTOMER_AMC_ENDDATE", nullable = false, length = 200)
	public Date getCustomerAmcEndDate() {
		return customerAmcEndDate;
	}
	public void setCustomerAmcEndDate(Date customerAmcEndDate) {
		this.customerAmcEndDate = customerAmcEndDate;
	}
	




}
