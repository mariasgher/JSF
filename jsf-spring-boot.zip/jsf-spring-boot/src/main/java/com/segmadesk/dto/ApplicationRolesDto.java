package com.segmadesk.dto;

import java.io.Serializable;
import java.util.Date;



public class ApplicationRolesDto implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -5526602597070916887L;
	private String roleId;
	private String appId;
	private String roleName;
	private String remarks;
	private String roleType;
	private String active;
	private String inputBy;
	private Date inputDate;
	
	
	public ApplicationRolesDto(String roleId, String appId, String roleName,  String roleType,
			String active, String inputBy, Date inputDate) {
		super();
		this.roleId = roleId;
		this.appId = appId;
		this.roleName = roleName;
		this.roleType = roleType;
		this.active = active;
		this.inputBy = inputBy;
		this.inputDate = inputDate;
	}
	public String getRoleId() {
		return roleId;
	}
	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}
	public String getAppId() {
		return appId;
	}
	public void setAppId(String appId) {
		this.appId = appId;
	}
	public String getRoleName() {
		return roleName;
	}
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getRoleType() {
		return roleType;
	}
	public void setRoleType(String roleType) {
		this.roleType = roleType;
	}
	public String getActive() {
		return active;
	}
	public void setActive(String active) {
		this.active = active;
	}
	public String getInputBy() {
		return inputBy;
	}
	public void setInputBy(String inputBy) {
		this.inputBy = inputBy;
	}
	public Date getInputDate() {
		return inputDate;
	}
	public void setInputDate(Date inputDate) {
		this.inputDate = inputDate;
	}
	
	
}
