package com.segmadesk.dto;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class ThreeColumnsMapper implements RowMapper<UserRolesApplications>{
	@Override
    public UserRolesApplications mapRow(ResultSet rs, int rowNum) throws SQLException {

		UserRolesApplications state = new UserRolesApplications();
		state.setUserId(rs.getString("USER_ID"));
		state.setAppId(rs.getString("APP_ID"));
		state.setAppUrl(rs.getString("APP_URL"));
		state.setAppDes(rs.getString("APP_DESCRIPTION"));
		state.setActive(rs.getString("ACTIVE"));
		state.setVerStatus(rs.getString("VER_STS"));
		return state;
    }
}
