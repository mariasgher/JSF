package com.segmadesk.dto;

import java.io.Serializable;

public class UserRolePicklistDto  implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -2053693915692448182L;
	private String appId;
	private String roleId;
	private String appName;
	private String roleName;
	
	
	public UserRolePicklistDto() {
		
	}
	public UserRolePicklistDto(String appId, String roleId, String appName, String roleName) {
		super();
		this.appId = appId;
		this.roleId = roleId;
		this.appName = appName;
		this.roleName = roleName;
	}
	public String getAppId() {
		return appId;
	}
	public void setAppId(String appId) {
		this.appId = appId;
	}
	public String getRoleId() {
		return roleId;
	}
	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public String getRoleName() {
		return roleName;
	}
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
	
	
	}
