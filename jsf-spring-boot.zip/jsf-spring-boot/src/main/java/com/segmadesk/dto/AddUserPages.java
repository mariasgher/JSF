package com.segmadesk.dto;

import java.io.Serializable;

public class AddUserPages implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String pageId;
	String FriendlyName;
	public String getPageId()  {
		return pageId;
	}
	public void setPageId(String pageId) {
		this.pageId = pageId;
	}
	public String getFriendlyName() {
		return FriendlyName;
	}
	public void setFriendlyName(String friendlyName) {
		FriendlyName = friendlyName;
	}


}
