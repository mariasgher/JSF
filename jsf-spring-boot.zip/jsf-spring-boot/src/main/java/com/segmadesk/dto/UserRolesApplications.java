package com.segmadesk.dto;

import java.io.Serializable;

public class UserRolesApplications implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5600940406333944528L;
	String appId;
	String userId;
	String appDes;
	String appUrl;
	String active;
	String verStatus;
	
	
	public String getAppId() {
		return appId;
	}
	public void setAppId(String appId) {
		this.appId = appId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getAppDes() {
		return appDes;
	}
	public void setAppDes(String appDes) {
		this.appDes = appDes;
	}
	public String getAppUrl() {
		return appUrl;
	}
	public void setAppUrl(String appUrl) {
		this.appUrl = appUrl;
	}

	public String getActive() {
		return active;
	}
	public void setActive(String active) {
		this.active = active;
	}
	public String getVerStatus() {
		return verStatus;
	}
	public void setVerStatus(String verStatus) {
		this.verStatus = verStatus;
	}







};