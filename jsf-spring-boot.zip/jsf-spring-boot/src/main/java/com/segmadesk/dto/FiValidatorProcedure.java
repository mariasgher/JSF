package com.segmadesk.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

public class FiValidatorProcedure  implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1168414967528912257L;

	private String status;
	private String description;
	private BigDecimal fiAmount;
	 
	public FiValidatorProcedure() {
		super();
		//TODO Auto-generated constructor stub
	}
	public FiValidatorProcedure(String status, String description, BigDecimal fiAmount) {
		super();
		this.status = status;
		this.description = description;
		this.fiAmount = fiAmount;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public BigDecimal getFiAmount() {
		return fiAmount;
	}
	public void setFiAmount(BigDecimal fiAmount) {
		this.fiAmount = fiAmount;
	}
	 
	 
}
