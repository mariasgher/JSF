package com.segmadesk.dto;

import java.io.Serializable;
import java.util.List;

public class StoreProcedureReturn  implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1168414967528912257L;
	String status;
	String description;
	String userName;
	
	List<String> lst;
	boolean isAppUser;
	String rolesId;
	List<UserRolesApplications> lstOfApplications;
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public List<String> getLst() {
		return lst;
	}
	public void setLst(List<String> lst) {
		this.lst = lst;
	}
	public List<UserRolesApplications> getLstOfApplications() {
		return lstOfApplications;
	}
	public void setLstOfApplications(List<UserRolesApplications> lstOfApplications) {
		this.lstOfApplications = lstOfApplications;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public boolean isAppUser() {
		return isAppUser;
	}
	public void setAppUser(boolean isAppUser) {
		this.isAppUser = isAppUser;
	}

	public String getRolesId() {
		return rolesId;
	}
	public void setRolesId(String rolesId) {
		this.rolesId = rolesId;
	}
	
}
