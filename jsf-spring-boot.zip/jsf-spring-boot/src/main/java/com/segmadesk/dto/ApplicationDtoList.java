package com.segmadesk.dto;

import java.io.Serializable;
import java.util.List;

public class ApplicationDtoList implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -6894777067281337135L;
	String applicationName;
	String appId;
	List<ApplicationRolesDto> applicationDtoLst;
	List<ApplicationRolesDto> selectedapplicationDtoLst;
	
	public ApplicationDtoList(String applicationName, String appId, List<ApplicationRolesDto> applicationDtoLst,List<ApplicationRolesDto> dtoListSelected) {
		super();
		this.applicationName = applicationName;
		this.appId = appId;
		this.applicationDtoLst = applicationDtoLst;
		this.selectedapplicationDtoLst = dtoListSelected;
	}
	
	public String getApplicationName() {
		return applicationName;
	}

	public void setApplicationName(String applicationName) {
		this.applicationName = applicationName;
	}

	public String getAppId() {
		return appId;
	}
	public void setAppId(String appId) {
		this.appId = appId;
	}
	public List<ApplicationRolesDto> getApplicationDtoLst() {
		return applicationDtoLst;
	}
	public void setApplicationDtoLst(List<ApplicationRolesDto> applicationDtoLst) {
		this.applicationDtoLst = applicationDtoLst;
	}

	public List<ApplicationRolesDto> getSelectedapplicationDtoLst() {
		return selectedapplicationDtoLst;
	}

	public void setSelectedapplicationDtoLst(List<ApplicationRolesDto> selectedapplicationDtoLst) {
		this.selectedapplicationDtoLst = selectedapplicationDtoLst;
	}

}
