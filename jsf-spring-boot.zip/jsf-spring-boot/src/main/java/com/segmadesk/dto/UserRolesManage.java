package com.segmadesk.dto;

import java.io.Serializable;
import java.util.Set;

import com.segmadesk.model.AppSysFunctions;
import com.segmadesk.model.AppSysModules;
import com.segmadesk.model.AppSysRoles;
import com.segmadesk.model.AppUsers;

public class UserRolesManage implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -7996420772559536912L;
	AppUsers User;
	Set<AppSysRoles> roles;
	Set<AppSysFunctions>  pages;
	Set<AppSysModules>  modules;
	boolean isUserrole=false ;
	public AppUsers getUser() {
		return User;
	}
	
	public boolean isUserrole() {
		return isUserrole;
	}

	public void setUserrole(boolean isUserrole) {
		this.isUserrole = isUserrole;
	}

	public void setUser(AppUsers user) {
		User = user;
	}

	public Set<AppSysRoles> getRoles() {
		return roles;
	}

	public void setRoles(Set<AppSysRoles> roles) {
		this.roles = roles;
	}

	public Set<AppSysFunctions> getPages() {
		return pages;
	}

	public void setPages(Set<AppSysFunctions> pages) {
		this.pages = pages;
	}

	public Set<AppSysModules> getModules() {
		return modules;
	}

	public void setModules(Set<AppSysModules> modules) {
		this.modules = modules;
	}
	




}
