package com.segmadesk.util;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;



@FacesConverter(value = "primeFacesUserLoginStatus")
public class PrimeFacesUserLoginStatus  implements Converter{

	@Override
	public Object getAsObject(FacesContext context, UIComponent component, String value) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getAsString(FacesContext context, UIComponent component, Object valueObject) {
		String value= valueObject.toString().trim();
		if(value.equalsIgnoreCase("A"))
		{
			return "Active";
		}else if(value.equalsIgnoreCase("L"))
		{
			return "Lock";
		}
		if(value.equalsIgnoreCase("I")){
			return "InActive";
		}
		
		if(value.equalsIgnoreCase("E")){
			return "Change Password";
		}
		if(value.equalsIgnoreCase("V")){
			return "Approved(V)";
		}
		if(value.equalsIgnoreCase("R")){
			return "Rejected(R)";
		}
		if(value.equalsIgnoreCase("U")){
			return "Update(U)";
		}
		if(value.equalsIgnoreCase("N")){
			return "New(N)";
		}
		if(value.equalsIgnoreCase("M")){
			return "Modify(M)";
		}
		if(value.equalsIgnoreCase("T")){
			return "Transactional Role";
		}
		if(value.equalsIgnoreCase("B")){
			return "Block";
		}
		if(value.equalsIgnoreCase("D")){
			return "Block From InActive";
		}
		if(value.equalsIgnoreCase("F")){
			return "Block From Active";
		}
		// TODO Auto-generated method stub
		return null;
	}

}
