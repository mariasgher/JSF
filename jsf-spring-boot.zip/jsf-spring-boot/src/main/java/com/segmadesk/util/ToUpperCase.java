package com.segmadesk.util;

import java.util.Date;

import com.segmadesk.model.AppRoleFunctions;
import com.segmadesk.model.AppSysRoles;
import com.segmadesk.model.AppUserRoles;
import com.segmadesk.model.AppUsers;

public class ToUpperCase {

	static public AppRoleFunctions pojotToUpperCase(AppRoleFunctions obj) {
		obj.setRemarks((obj.getRemarks() == null) ? "" : obj.getRemarks().toUpperCase());
		return obj;
	}

	static public AppUserRoles pojotToUpperCase(AppUserRoles obj) {
		obj.setRemarks((obj.getRemarks() == null) ? "" : obj.getRemarks().toUpperCase());
		return obj;
	}

	static public AppSysRoles pojotToUpperCase(AppSysRoles obj) {

		obj.setRemarks((obj.getRemarks() == null) ? "" : obj.getRemarks().toUpperCase());
		return obj;
	}

	static public AppUsers pojotToUpperCase(AppUsers obj) {
		obj.setRemarks((obj.getRemarks() == null) ? "" : obj.getRemarks().toUpperCase());
		obj.setUsername((obj.getUsername() == null) ? "" : obj.getUsername().toUpperCase());
		obj.setEmail((obj.getEmail() == null) ? "" : obj.getEmail().toLowerCase());
		return obj;
	}


	public static AppSysRoles pojoIdToUpperCase(AppSysRoles roles) {
		roles.getId().setRoleId((roles.getId().getRoleId() == null) ? "" : roles.getId().getRoleId().toUpperCase());
		roles.setRemarks((roles.getRemarks() == null) ? "" : roles.getRemarks().toUpperCase());
		return roles;
	}

}
