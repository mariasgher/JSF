package com.segmadesk.util;

import java.util.ArrayList;
import java.util.List;

@SuppressWarnings ( "javadoc")
public class Constants {
	public static final boolean LOGGING_ENABLED = true;
	public static final String SERVER_MODULE_NAME="/pswapp";
	public static final String PASSWORD_WRONG="Invalid username or password";
	public static final String LOGIN_SESSION_KEY_USER="login_session_key_$a!m@_user";
	public static final String LOGIN_SESSION_KEY_MODULE="login_session_key_$a!m@_module";
	public static final String LOGIN_CUST_SESSION_KEY_USER="login_session_key_cu@t_user";
	public static final String LOGIN_CUST_SESSION_KEY_USER_PROC="login_session_key_cu@t_pr@@_user";

	public static final String PROGRESS_SESSION="PROGRESS_SESSION";
	//public static final String USER_LICENCE ="";
	//public static final String USER_LICENCE_APPROVED ="";
	public static final String USER_SESSION_KEY="user_session_key_$a!m@";
	public static final String UNGROUP="no-group";
	public static final String ADD_USER_AUTHORITY= "ADD_USER";

	public static final String HIBERNATE_PASS_KEY = "@!@#UBPS_PROD#@@";
	public static final String HIBERNATE_PASS_INTVECTOR = "@!@#UBPS())((#@@";

	public static final String HIBERNATE_ENCRYPT_CHECK= "ENC/P#%T/T";
	public static final String 	NEWPASSWORD= "p@$w0r@";


	public static List<String> PagesList= new ArrayList<String>();


	public static int NUMBER_OF_USER = 10;

	/**
	 * for SMTP 
	 **/
	
	//public static final String URLConstant="/daasmanager/";
	/**
	 * end of SMTP
	 */
	public static final String LOGIN_SESSION_KEY_USER_DESC="login_session_key_$a!m@_user_desc";
	public static final String APPNAME = "psw";
	/**
	 * date time foramt string
	 */

	public interface DateFormats {
		String DATE_TIME_FORMAT = "yyyy-MM-dd HH:mm:ss";// 2011-04-11 12:44:59
		String DATE_ONLY_FORMAT = "yyyy-MM-dd";
		String DATE_US_FORMAT = "MM/dd/yyyy";
		String DATE_TIME_US_FORMAT = "MM/dd/yyyy HH:mm:ss";
		String DATE_TIME_US_FORMAT_EX_SECONDS = "MM/dd/yyyy HH:mm";
		String DATE_TIME_ZONE_US_FORMAT = "MM/dd/yyyy HH:mm:ss zzz";
		String DATE_TIME_ZONE_US_AM_PM_FORMAT = "MM/dd/yyyy hh:mm:ss aa";
		String DATE_TIME_ZONE_FORMAT_COMPLETE = "EEE MMM dd yyyy HH:mm:ss zzz";
		String EMPTY_DATE = "0-0";
		String DATE_TIME_FORMAT_OF_PROJECT = "yyyy/MM/dd HH:mm:ss";

	}

	public interface StringConstants {
		String EMPTY_STRING = "";
		String UTF8 = "UTF8";
		String NA = "N.A";
	}


	public interface SegmaActiveUser{
		String ActiveUser= "A";
		String InActive = "I";
		
	}
	
	public interface SegmaPagesView{
		String ActivePages= "Y";
		String InActivePages = "N";
		
	}
	
	public interface SegmaPassowrdUser{
		String FirstTime= "E";
		String ActiveUser = "A"; 
		String Lock = "L";
	}
	
	public interface SegmaEmpUser{
		String PermanenetUser= "P";
		String ContractualUer = "C";
	}
	
	public interface SegmaMakerCheckerStatus{
		String Approve= "V";
		String NewUser = "N";
		String EditUser = "E";
		String Reject = "R";
		String Updated = "U";	
		String Complete="C";
		String Pending="P";

	}
	
	public interface FXChangePass {
		String PASSWORD_CHANGE_VERIFY = "PCV";
		String PASSWORD_CHANGE = "PC";

	}
	public interface Flags {
		String SUCCESS = "S";

	}
	
	public interface SegmaStatus{
		String ActiveUser= "A";
		String InActive = "I";
		String Block = "B";
		String Delete = "D";
	}
	
	public interface SegmaRoleTypes{
		String M = "M";
		String T = "T";
	}
	
	public interface SegmaRoleType{
		String Transactional= "T";
		String Reporting = "M";
	}
	public interface SegmaVerUser{
		String Approve= "V";
		String NewUser = "N";
		String EditUser = "E";
		String Reject = "R";
		String Updated = "U";

	}
	public interface ApplicationName{
		String APPLICATION_NAME = "Segmadesk";
	}
	
	
	public interface StaticStatus{
		String Static_Inputter = "SDMU_INP";	
		String Static_Approver = "SDMU_SUP";	
	}
	public interface LoginPocedure{
		String UserVerification = "UV";	
		String UserLogin = "UL";	
	}
	
	
	
	
}


