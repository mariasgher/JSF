package com.segmadesk.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.CRC32;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class Utility {
	 private static final Logger userLogs = LogManager.getLogger(Utility.class);
	 
	public static String getWebImagePath() {
		try {
			String temp = HttpUtility.getContaxtPath();
			return temp + "images" + File.separatorChar;
		} catch (Exception e) {
			userLogs.error(e);
			return "";
		}
	}

	public static Date getTime() {
		Calendar cal = Calendar.getInstance();
		// cal.add(Calendar.HOUR_OF_DAY,Constants.GMT_SERVER_DIFFERENCE);
		return cal.getTime();
	}

	public static void reportError(String from_id, String to_id, String message) {
		HttpUtility.redirect("error.jsf?fromID=" + from_id + "&toID=" + to_id + "&msg=" + message);
	}

	public static String getRandomNumber() {
		Random randomGenerator = new Random();
		int randomInt = randomGenerator.nextInt(8852314);
		return String.valueOf(randomInt);
	}

	public static boolean isValidEmail(String email) {
		boolean matchFound = false;
		if (email != null) {
			Pattern p = Pattern.compile(".+@.+\\.[a-z]+");
			Matcher m = p.matcher(email);
			matchFound = m.matches();
		}
		return matchFound;
	}

	public static boolean isValidMobile(String mob) {
		Pattern p = Pattern.compile("923\\d\\d\\d\\d\\d\\d\\d\\d\\d");
		Matcher m = p.matcher(mob);
		return m.matches();
	}

	public static String URLEncode(String s) {
		if (s != null) {
			StringBuffer tmp = new StringBuffer();
			int i = 0;
			try {
				while (true) {
					int b = (int) s.charAt(i++);
					if ((b >= 0x30 && b <= 0x39) || (b >= 0x41 && b <= 0x5A) || (b >= 0x61 && b <= 0x7A)) {
						tmp.append((char) b);
					} else {
						tmp.append("%");
						if (b <= 0xf) {
							tmp.append("0");
						}
						tmp.append(Integer.toHexString(b));
					}
				}
			} catch (Exception e) {
			}
			return tmp.toString();
		}
		return null;
	}

	public boolean doZip(String filename, String zipfilename) {
		try {
			byte[] buf = new byte[1024];
			FileInputStream fis = new FileInputStream(filename);
			fis.read(buf, 0, buf.length);

			CRC32 crc = new CRC32();
			ZipOutputStream s = new ZipOutputStream((OutputStream) new FileOutputStream(zipfilename));

			s.setLevel(6);

			ZipEntry entry = new ZipEntry(filename);
			entry.setSize((long) buf.length);
			crc.reset();
			crc.update(buf);
			entry.setCrc(crc.getValue());
			s.putNextEntry(entry);
			s.write(buf, 0, buf.length);
			s.finish();
			s.close();
			return true;
		} catch (Exception e) {
			userLogs.error(e);
		}
		return false;
	}

	public static String convertDateToString(Date date) {
		Calendar c = Calendar.getInstance();
		c.setTime(date);
		String dateTimeClient = Utility.getMonth(c.get(Calendar.MONTH)) + ", " + c.get(Calendar.DATE) + " " + c.get(Calendar.YEAR) + " " + c.get(Calendar.HOUR)
				+ ":" + c.get(Calendar.MINUTE) + ":" + c.get(Calendar.SECOND) + " " + ((c.get(Calendar.AM_PM) == 0) ? "AM" : "PM");
		return dateTimeClient;
	}

	public static String getMonth(int monthNum) {

		String month = "";
		switch (monthNum) {
		case 0:
			month = "January";
			break;
		case 1:
			month = "February";
			break;

		case 2:
			month = "March";
			break;

		case 3:
			month = "April";
			break;

		case 4:
			month = "May";
			break;

		case 5:
			month = "June";
			break;

		case 6:
			month = "July";
			break;
		case 7:
			month = "August";
			break;
		case 8:
			month = "September";
			break;
		case 9:
			month = "October";
			break;
		case 10:
			month = "November";
			break;
		case 11:
			month = "December";
			break;
		}
		return month;
	}

	public int getUTC(String date) {
		String gmt = "";
		boolean flag = false;
		for (int i = 0; i < date.length(); i++) {
			if (date.charAt(i) == '+' || date.charAt(i) == '-' || flag) {
				if (date.charAt(i) == '+') {
					flag = true;
					continue;
				}
				gmt = gmt + date.charAt(i);
				if (date.charAt(i) == ' ')
					flag = false;
				else
					flag = true;

			}
		}
		// return -1*(Integer.parseInt(gmt.trim())/100);
		int hr = -1 * (Integer.parseInt(gmt.trim()) / 100);
		// if(hr > 0 ){
		// return hr-1;
		// }else{
		return hr;
		// }
	}

	public static boolean ping(String ip) {
		
		String pingResult = "";
		String pingCmd = "ping " + ip;

		try {
			Runtime r = Runtime.getRuntime();
			Process p = r.exec(pingCmd);

			BufferedReader in = new BufferedReader(new InputStreamReader(p.getInputStream()));
			String inputLine;
			while ((inputLine = in.readLine()) != null) {				
				pingResult += inputLine;
			}
			in.close();			
			return pingResult.indexOf("TTL=")!=-1;
		}
		catch (Exception e) {
			return false;
		}

	}

}
