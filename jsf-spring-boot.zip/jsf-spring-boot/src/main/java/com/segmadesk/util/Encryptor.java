package com.segmadesk.util;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.segmadesk.mb.LoginMB;

public class Encryptor {
	 private static final Logger LOGGER = LogManager.getLogger(LoginMB.class);
	 
	public static String encrypt(String key, String initVector, String value) {
		try {
			IvParameterSpec iv = new IvParameterSpec(initVector.getBytes("UTF-8"));
			SecretKeySpec skeySpec = new SecretKeySpec(key.getBytes("UTF-8"), "AES");

			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
			cipher.init(Cipher.ENCRYPT_MODE, skeySpec, iv);

			byte[] encrypted = cipher.doFinal(value.getBytes());
			LOGGER.info("encrypted string: "
					+ Base64.encodeBase64(encrypted));

			return new String(Base64.encodeBase64(encrypted));
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return null;
	}

	public static String decrypt(String key, String initVector, String encrypted) {
		try {
			IvParameterSpec iv = new IvParameterSpec(initVector.getBytes("UTF-8"));
			SecretKeySpec skeySpec = new SecretKeySpec(key.getBytes("UTF-8"), "AES");

			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
			cipher.init(Cipher.DECRYPT_MODE, skeySpec, iv);
			LOGGER.debug("Decrypt Lenght:"+encrypted.length());
			byte[] original = cipher.doFinal(Base64.decodeBase64(encrypted.getBytes()));

			return new String(original);
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return null;
	}

	public static void main(String[] args) {
		final String FILENAME = "D:\\filename.txt";

		String key = Constants.HIBERNATE_PASS_KEY;// 128 bit key
		LOGGER.debug("Key Lenght"+key.length());
		//	String key = "Bar3323##12345Bar12345";
		String initVector =Constants.HIBERNATE_PASS_INTVECTOR; // 16 bytes IV
		//	LOGGER.debug(initVector.length());
		String encrypt = encrypt(key, initVector, "segmatek_tom$543");
		LOGGER.debug("before Enc "+encrypt);
		encrypt = Constants.HIBERNATE_ENCRYPT_CHECK+encrypt;
		try (BufferedWriter bw = new BufferedWriter(new FileWriter(FILENAME))) {

			String content = encrypt;

			bw.write(content);

			// no need to close it.
			//bw.close();

			LOGGER.debug("Done");

		} catch (IOException e) {

			e.printStackTrace();

		}
		LOGGER.debug("add enc "+encrypt);
		if(encrypt.startsWith(Constants.HIBERNATE_ENCRYPT_CHECK)){
			encrypt = encrypt.replaceFirst(Constants.HIBERNATE_ENCRYPT_CHECK, "");
			LOGGER.debug(decrypt(key, initVector,encrypt));
		}
		else{
			LOGGER.debug("encrypt it");
		}
		

		
	}
}