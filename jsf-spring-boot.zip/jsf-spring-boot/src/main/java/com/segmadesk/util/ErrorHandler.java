package com.segmadesk.util;

import java.io.Serializable;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

@ManagedBean(name = "ErrorHandler")
@SessionScoped
public class ErrorHandler implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -7082541534779403517L;


	public  String message;
	public   String cause;
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getCause() {
		return cause;
	}
	public void setCause(String cause) {
		this.cause = cause;
	}
	public ErrorHandler(String message, String cause) {
		super();
		this.message = message;
		this.cause = cause;
	}
	public ErrorHandler() {
		super();
	}

}
