package com.segmadesk.util;

public class ClientPageException extends Exception{

	/**
	 * 
	 */
	static String msg;
	private static final long serialVersionUID = 3414038563311488757L;
	public  ClientPageException(){
	     super(msg);
	  }
	public  ClientPageException(String message){
	     super(message);
	  }
	public  void setMessage(String message){
	    msg=message;
	  }
	
}
