package com.segmadesk.util;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

@FacesConverter(value = "primeFacesIncidentStatus")
public class PrimefacesIncident  implements Converter{

	@Override
	public Object getAsObject(FacesContext context, UIComponent component, String value) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getAsString(FacesContext context, UIComponent component, Object valueObject) {
		String value= valueObject.toString().trim();
		if(value.equalsIgnoreCase("A"))
		{
			return "Active";
		}else if(value.equalsIgnoreCase("L"))
		{
			return "Lock";
		}
		if(value.equalsIgnoreCase("I")){
			return "InActive";
		}
		
		if(value.equalsIgnoreCase("E")){
			return "Edited";
		}
		if(value.equalsIgnoreCase("V")){
			return "Email Sent";
		}
		if(value.equalsIgnoreCase("P")){
			return "Approved Waiting for Email to be sent";
		}
		if(value.equalsIgnoreCase("R")){
			return "Rejected";
		}
		if(value.equalsIgnoreCase("U")){
			return "Update";
		}
		if(value.equalsIgnoreCase("N")){
			return "New";
		}
		if(value.equalsIgnoreCase("M")){
			return "Reporting Role";
		}
		if(value.equalsIgnoreCase("T")){
			return "Transactional Role";
		}
		if(value.equalsIgnoreCase("B")){
			return "Block";
		}
		
		if(value.equalsIgnoreCase("D")){
			return "Deleted";
		}
		// TODO Auto-generated method stub
		return null;
	}

}
