package com.segmadesk.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Properties;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class PropertiesFilePath implements Serializable  {
	/**
	 * 
	 */
	private static final long serialVersionUID = -3889392018679553780L;
	static public Properties	prop=null ;
	public String filename = "config.properties";
	
	 private static final Logger userLogs = LogManager.getLogger(PropertiesFilePath.class);
	 
	 
	public void loadPropertiesFile(){
		prop = new Properties();
		InputStream input = null;

		try {


			input = getClass().getClassLoader().getResourceAsStream(filename);
			if(input==null){
				userLogs.error("Sorry, unable to find " + filename);
				return;
			}

			//load a properties file from class path, inside static method
			prop.load(input);

		} catch (IOException ex) {
			ex.printStackTrace();
		} finally{
			if(input!=null){
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

	}

	public void saveInPropertyFiles(ArrayList<String> keys, ArrayList<String> values,String path){
		Properties outProp = new Properties();
		OutputStream output = null;

		try {

			userLogs.error("PATH:"+path);
			File f = new File(path+"WEB-INF/classes/hibernate.properties");
			userLogs.debug(f.getPath());
			userLogs.debug(f.getAbsolutePath());
			try {
				userLogs.debug(f.getCanonicalPath());
			}catch (Exception e){

			}
			output = new FileOutputStream(f);
			outProp.load(getClass().getClassLoader().getResourceAsStream("hibernate.properties"));
			// set the properties value
			for (int i = 0; i < values.size(); i++) {
				outProp.setProperty(keys.get(i), values.get(i));
				
			}
			outProp.setProperty("hibernate.show_sql", "true");
			outProp.setProperty("hibernate.format_sql", "true");
			

			// save properties to project root folder
			outProp.store(output, null);

		} catch (IOException io) {
			io.printStackTrace();
		} finally {
			if (output != null) {
				try {
					output.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}

		}
	}

	public String getProptyvalue(String key,String filename){
		Properties inputProp = new Properties();
		InputStream input = null;

		try {


			input = getClass().getClassLoader().getResourceAsStream(filename);
			if(input==null){
				userLogs.debug("Sorry, unable to find " + filename);
				return "";
			}

			// load a properties file
			inputProp.load(input);

			// get the property value and print it out
			return inputProp.getProperty(key);

		} catch (IOException ex) {
			ex.printStackTrace();
		} finally{
			if(input!=null){
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return "";

	}
	public static void main(String[] args) {


	}
	
}
