/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.segmadesk.util;

import java.util.Map;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;




public class HttpUtility {

	private static final Logger userLogs = LogManager.getLogger(HttpUtility.class);
	public static String getContaxtPath()throws Exception{		
		ServletContext servletContext = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
		String path=servletContext.getRealPath("ubps");
		return path.substring(0,path.lastIndexOf("ubps"));
	}

	public static HttpServletRequest getRequest() throws SegmaException {
		HttpServletRequest request = (HttpServletRequest) FacesContext
				.getCurrentInstance().getExternalContext().getRequest();
		return request;
	}

	public static Object getSession(String key) throws SegmaException {
		if(FacesContext.getCurrentInstance()==null) {
			return null;
		}
		Map session = FacesContext.getCurrentInstance().getExternalContext()
				.getSessionMap();
		Object obj = session.get(key);
		/*if (obj == null) {
			return null;
			//throw new SessionException("Session expired or no session.");
		}*/
		return obj;
	}

	public static void removeSession(String key) throws SegmaException {
		Map session = FacesContext.getCurrentInstance().getExternalContext()
				.getSessionMap();
		session.remove(key);
	}

	public static void setSession(String key, Object object) throws SegmaException {
		Map< String, Object > session = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
		session.put(key, object);
	}

	public static void redirect(String pageUrl) {

		if(FacesContext.getCurrentInstance()==null) {

		}
		else {
			ExternalContext extCon = null;
			try {
				extCon = FacesContext.getCurrentInstance().getExternalContext();
				extCon.redirect(pageUrl);
			} catch (Exception e) {
				try {
					extCon.redirect(Constants.APPNAME+pageUrl);
				} catch (Exception ex) {
					userLogs.error(ex);
				}
			}
		}
	}


	public static void redirectApp(String pageUrl) {
		ExternalContext extCon = null;
		try {
			extCon = FacesContext.getCurrentInstance().getExternalContext();
			extCon.redirect(pageUrl);
		} catch (Exception e) {
			try {
				extCon.redirect(pageUrl);
			} catch (Exception ex) {
				userLogs.error(ex);
			}
		}
	}

	public HttpServletRequest getRequestObject() {
		HttpServletRequest request = (HttpServletRequest) FacesContext
				.getCurrentInstance().getExternalContext().getRequest();
		return request;
	}

	public static HttpServletResponse getResponseObject() {
		HttpServletResponse response = (HttpServletResponse) FacesContext
				.getCurrentInstance().getExternalContext().getResponse();
		return response;
	}

	public static HttpSession getUserSession() {
		ExternalContext ext = FacesContext.getCurrentInstance().getExternalContext();
		HttpSession session = (HttpSession) ext.getSession(false);
		return session;
	}

	/*public static void removeAllCookies(){
		 Cookie[] cookies = request.getCookies();  
         Cookie opentoken = null;  
         for(Cookie c : cookies){  
             if (c.getName().equals("opentoken")){  
                 logger.debug("found the cookie: "+c.getName()+" domain:"+c.getDomain()+" exp:"+c.getMaxAge()); // log4j debug statement  
                 opentoken = c;  
                 opentoken.setMaxAge(0);  
                 opentoken.setValue(""); // it is more elegant to clear the value but not necessary  
                 response.addCookie(opentoken);  
                 logger.debug("redirecting to "+request.getContextPath());  
                 response.sendRedirect(request.getContextPath());  
                 break;  
             }  
         }  
	}*/

}
