package com.segmadesk.util;

public class SegmaException extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = -8225596418184020597L;

	/**
	 * 
	 */


	
	public String getMessage(Exception e){
			return e.getMessage();
		
	}
	public SegmaException()
	{
	}

	public SegmaException(String message)
	{
		super(message);
	}

	public SegmaException(Throwable cause)
	{
		super(cause);
	}

	public SegmaException(String message, Throwable cause)
	{
		super(message, cause);
	}

	public SegmaException(String message, Throwable cause, 
                                       boolean enableSuppression, boolean writableStackTrace)
	{
		super(message, cause, enableSuppression, writableStackTrace);
	}
}




