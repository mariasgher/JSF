package com.segmadesk.util;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

@FacesConverter(value = "primefacesManageBranchConvertor")
public class PrimefacesManageBranchConvertor  implements Converter{

	@Override
	public Object getAsObject(FacesContext context, UIComponent component, String value) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getAsString(FacesContext context, UIComponent component, Object valueObject) {
		String value= valueObject.toString().trim();
		
		if(value.equalsIgnoreCase("V")){
			return "Authorized";
		}
		if(value.equalsIgnoreCase("R")){
			return "Rejected";
		}
		if(value.equalsIgnoreCase("N")){
			return "UnAuthorized";
		}
		
		return null;
	}

}
