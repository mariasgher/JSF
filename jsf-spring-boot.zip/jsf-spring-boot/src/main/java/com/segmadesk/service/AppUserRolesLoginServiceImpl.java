package com.segmadesk.service;

import java.io.Serializable;
import java.util.List;

import com.segmadesk.dao.AppUserRolesLoginHome;
import com.segmadesk.dto.StoreProcedureReturn;
import com.segmadesk.dto.UserRolePicklistDto;
import com.segmadesk.model.AppUserRoles;
import com.segmadesk.util.SegmaException;

import org.primefaces.model.DualListModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class AppUserRolesLoginServiceImpl implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 8345615487211735414L;
	@Autowired 
	private AppUserRolesLoginHome userRoleDao;

	public String getRoleAgainstUserId(String userID) throws SegmaException {
		{

			List<String> lstObj = userRoleDao.getRoleAgainstUserId(userID);
			return (lstObj.size() >= 1 ? lstObj.get(0) : null);
		}

	}

	public int rejectRole(String roleId, String appId, String userId) throws SegmaException {
		{

			return userRoleDao.rejectRole(roleId, appId, userId);

		}

	}

	
	public List<AppUserRoles> getAppUserRolesAgainstApplication(String systemId, String userId) throws SegmaException {
		{

			return userRoleDao.getAppUserRolesAgainstApplication(systemId, userId);
//return null;
		}

	}

	
	public List<AppUserRoles> getAllInActiveUserRole(String userId) throws SegmaException {
		return userRoleDao.getAllInActiveUserRole(userId);

	}

	public List<UserRolePicklistDto> getAppUserRolesDtoAgainstApplication(String systemId, String userId)
			throws SegmaException {
		return userRoleDao.getAppUserRolesDtoAgainstApplication(systemId, userId);

	}

	
	public int saveUserRole(String userRole, DualListModel<String> target, StoreProcedureReturn manage, String selSystem,
			String selUserId) throws SegmaException {
		return userRoleDao.saveUserRole(userRole, target, manage, selSystem, selUserId);

	}
}
