package com.segmadesk.service;

import java.io.Serializable;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.segmadesk.dao.AppUsersLoginHome;
import com.segmadesk.dto.StoreProcedureReturn;
import com.segmadesk.dto.UserRolesApplications;
import com.segmadesk.model.AppUsers;
import com.segmadesk.util.SegmaException;


@Service("userLoginService")
@Transactional
public class UserLoginServiceImpl implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 6640387046831486161L;
	@Autowired
	private AppUsersLoginHome userDao;


	
	public AppUsers getAppUsers(String userName) throws SegmaException {
		return  userDao.getAppUsers(userName);

	}


	
	public StoreProcedureReturn  firstTimeLogin(final String userName,final String password) throws SegmaException{
		try {
			return 	userDao.firstTimeLogin(userName,password);
		} catch (SQLException e) {
			throw new SegmaException(e);
		}

	}

	
	public StoreProcedureReturn SendEmail(String userid, String callFlag) throws SQLException, SegmaException {

		return userDao.SendEmail(userid, callFlag)	;
	}


	
	public String encryptPassword(String securePasswd) throws SegmaException {
		return userDao.encryptPassword(securePasswd);
	}


	
	public List<AppUsers> getUsersNotCreatedBy(String userid) throws SegmaException {
		return userDao.allUsers();
	}
	
	public List<AppUsers> getUsersForRole(String userid) throws SegmaException {
		return userDao.allUsers();
	}
	
	
	public List<AppUsers> allUsers( ) throws SegmaException {
		return userDao.allUsers();
	}
	
	public List<AppUsers> rejUsers( String userid) throws SegmaException {
		return userDao.rejUsers(userid);
	}
	
	public List<AppUsers> pendingUsers(String userid) throws SegmaException {
		return userDao.pendingUsers(userid);
	}


	
	public boolean isUsernameExist(String username) throws SegmaException {
		return userDao.isUsernameExist(username);
	}


	
	public int blockUser(AppUsers pojotToUpperCase, String userId) throws SegmaException {
		return userDao.blockUser(pojotToUpperCase, userId);
		
	}


	
	
	public StoreProcedureReturn ChangePassword(String username, String password,String oldPassword) throws SQLException,SegmaException {
		
			return userDao.ChangePassword(username,  password, oldPassword);
		
	}
	
	
	public List<UserRolesApplications> getApplicationName(String username) throws SQLException,SegmaException {
		
			return userDao.getApplicationName(username);
		
	}


	
	public boolean getRole(String userName,  int i) throws SegmaException {
		if(1==i) return (userDao.getRoles(userName,i).size()>=1)?true:false;
		if(2==i) return (userDao.getRoles(userName,i).size()>=1)?true:false;
		return false;
	}
	
}
