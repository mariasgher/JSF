package com.segmadesk.service;

import java.io.Serializable;
import java.util.List;

import com.segmadesk.dao.IAppSystemHome;
import com.segmadesk.model.AppSystems;
import com.segmadesk.util.SegmaException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service("systemService")
@Transactional
public class SystemServiceImpl implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -302487773395920109L;
	/**
	 * 
	 */
	@Autowired
	private IAppSystemHome appSystemDao;


	
	
	
	
	public List<AppSystems> getAllSystem() throws SegmaException {
		return appSystemDao.getAllSystem();
	}
		
	public AppSystems getSelectedSystem(String appId) throws SegmaException {
		return appSystemDao.getSelectedSystem(appId);
	}
}
