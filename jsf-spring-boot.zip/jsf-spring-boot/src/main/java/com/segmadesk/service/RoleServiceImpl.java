package com.segmadesk.service;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

import com.segmadesk.dao.IAppRolesHome;
import com.segmadesk.dto.UserRolePicklistDto;
import com.segmadesk.model.AppSysRoles;
import com.segmadesk.util.SegmaException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service("roleService")
@Transactional
public class RoleServiceImpl implements Serializable {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1278765277392893093L;
	@Autowired
	private IAppRolesHome roleDao;
	
	

	public List<AppSysRoles> getAllActiveAppRoles() throws SegmaException {
		return  roleDao.getAllAppRoles();
	
	}


	
	public Collection getRolesAgainstId(List<String> asList) throws SegmaException {
		return roleDao.getRolesAgainstId(asList);
		
	}


	
	public List<AppSysRoles> getAllRoles() throws SegmaException {
		return  roleDao.getAllRoles();
	
	}


	
	public List getAllAppRoles()  throws SegmaException {
		return roleDao.getAllAppRoles();
	
	}

	
	public List<AppSysRoles> getAllAppRolesAgainstApplication(String systemId)  throws SegmaException {
		return roleDao.getAllAppRolesAgainstApplication(systemId);
	
	}
	
	public List<UserRolePicklistDto> getAllAppRolesDtoAgainstApplication(String systemId) throws SegmaException{
		
			return roleDao.getAllAppRolesDtoAgainstApplication(systemId);
	}
	

	
	public int approve(AppSysRoles userApproveObj, String userId,String appId)throws SegmaException {
		return roleDao.approve(userApproveObj, userId,appId);
		
	}


	
	public void reject(AppSysRoles userApproveObj, String userId,String appId)throws SegmaException {
		 roleDao.reject(userApproveObj, userId,appId);
		
	}

	
	public List getSdmuRole(String userID, String staticInputter) throws SegmaException {
		return roleDao.getSdmuRole( userID,  staticInputter);
	
	}
	

	
}
