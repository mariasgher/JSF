package com.segmadesk.service;

import java.io.Serializable;
import java.util.List;

import com.segmadesk.dao.IAppModulesHome;
import com.segmadesk.model.AppSysModules;
import com.segmadesk.util.SegmaException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ModuleServiceImpl implements Serializable {
	

	/**
	 * 
	 */
	private static final long serialVersionUID = 9072004295392375687L;
	@Autowired
	private IAppModulesHome moduleDao;

	public List<AppSysModules> getAllModules() throws SegmaException {
		return moduleDao.getAllModules();
	
	}

}
