package com.segmadesk.service;

import java.io.Serializable;
import java.util.List;

import com.segmadesk.dao.IAppFunctionsHome;
import com.segmadesk.model.AppSysFunctions;
import com.segmadesk.util.SegmaException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FunctionsServiceImpl implements Serializable {
	

	/**
	 * 
	 */
	private static final long serialVersionUID = 9072004295392375687L;
	@Autowired
	private IAppFunctionsHome functionDao;

	
	public List<AppSysFunctions> getAllPages() throws SegmaException {
		
		return functionDao.getAllPages();
	
	}

}
