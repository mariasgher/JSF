package com.segmadesk.service;

import java.io.Serializable;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import com.segmadesk.dao.AppUserRolesLoginHome;
import com.segmadesk.dao.AppUsersLoginHome;
import com.segmadesk.dao.ICommonHome;
import com.segmadesk.dto.StoreProcedureReturn;
import com.segmadesk.model.AppSysRoles;
import com.segmadesk.model.AppUserRoles;
import com.segmadesk.model.AppUsers;
import com.segmadesk.util.SegmaException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class CommonServiceImpl implements  Serializable {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = -318966243221638407L;
	@Autowired
	private ICommonHome commonDao;
	
	@Autowired
	private AppUsersLoginHome userDao;
	
	@Autowired
	private 
	AppUserRolesLoginHome userRoles;
	
	public boolean savePages(String userRole, List<String> selectedPages,StoreProcedureReturn manage, String appId) throws SegmaException {
		return commonDao.savePages(userRole, selectedPages, manage,appId);
		
	}


	public int updateBean(Object beanObj) throws SegmaException {
		
		int result = commonDao.updateBean(beanObj);
		return result;
		
	}


	public int updateUser(AppUsers beanObj) throws SegmaException {
		
		return commonDao.updateUser(beanObj);		
	}
	
	public int updateUserRole(AppUserRoles beanObj) throws SegmaException {
	AppUserRoles reslt= userRoles.save(beanObj);
		
		return 1;
		
	}


	
	public boolean saveBean(Object bean) throws SegmaException, SQLIntegrityConstraintViolationException {
		return commonDao.saveBean(bean);
		
	}

	
	public boolean updateRolesUserFunction(AppSysRoles userEditObj) throws SegmaException {
		return commonDao.updateRolesUserFunction(userEditObj);
		
	}

	
	public int updateMultipleObject(Object userEditObj, List<AppUserRoles> roleuserlst) throws SegmaException {
		return commonDao.updateMultipleObject(userEditObj,  roleuserlst);
		
	}

	
	public boolean updateRolesUser(AppUsers userEditObj) throws SegmaException {
		return commonDao.updateRolesUser(userEditObj);
		
	}
	
	public AppSysRoles getRolesAgainstApplication(String name) throws SegmaException {
		return commonDao.getRolesAgainstApplication(name);
		
	}

	
	public boolean saveMultipleObject(AppUsers appUsers, List<AppUserRoles> roleuserlst) throws SegmaException {
		
		userDao.save(appUsers);
		
		
		for (Iterator iterator = roleuserlst.iterator(); iterator.hasNext();) {
			AppUserRoles appUserRoles = (AppUserRoles) iterator.next();
			userRoles.save(appUserRoles);
		}
		
		return true;
		
	}

	

	
	public boolean updateMultipleUserObject(List<AppUsers> users, String userID)
			throws SegmaException {
		return commonDao.updateMultipleUserObject(users, userID);
		
	}

	
	public Date getSystemDate() throws SegmaException {
		return commonDao.getSystemDate();	
	}

	
	
	public boolean reactivateBranchUsers(List<AppUsers> users, String userID) throws SegmaException {
		return commonDao.reactivateBranchUsers(users, userID);
	}
	
}
