package com.segmadesk.service;

import java.io.Serializable;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.segmadesk.dao.IAppRoleFunctionsLoginHome;
import com.segmadesk.model.AppRoleFunctions;
import com.segmadesk.util.SegmaException;

@Service("roleFunctionLoginService")
@Transactional
public class RoleFunctionLoginServiceImpl implements Serializable  {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 447445535047726550L;
	@Autowired
	private IAppRoleFunctionsLoginHome roleFunctionDao;

	
	public List<String> getAlreadyAddedPages(String roleId) throws SegmaException {
		return  roleFunctionDao.getAlreadyAddedPages(roleId);
		
	}

	
	public List<AppRoleFunctions> getAllRolePages() throws SegmaException {
		return roleFunctionDao.getAllRolePages();
	
	}

	
	public List<String> getPickListPages(String userRole, String appId) throws SegmaException {
		return roleFunctionDao.getPickListPages(userRole, appId);
	}


	public List<AppRoleFunctions> getAllPages(String role, String appId) throws SegmaException {
		return roleFunctionDao.getAllPages(role,appId);
	}

	
	public int blockRoleFunction(AppRoleFunctions pojotToUpperCase, String userid) throws SegmaException {
		return roleFunctionDao.blockRoleFunction(pojotToUpperCase, userid);
		
	}

	
	
	

}
