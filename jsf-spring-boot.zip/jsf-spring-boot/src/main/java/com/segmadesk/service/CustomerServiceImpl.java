package com.segmadesk.service;

import java.io.Serializable;
import java.sql.SQLIntegrityConstraintViolationException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.segmadesk.dao.ICustomer;
import com.segmadesk.model.Customer;
import com.segmadesk.util.SegmaException;

@Service
@Transactional
public class CustomerServiceImpl implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -318966243221638407L;
	@Autowired
	private ICustomer icust;

	public int saveBean(Customer customer) throws SegmaException, SQLIntegrityConstraintViolationException {

		icust.saveBean(customer);
		return 1;

	}

}
