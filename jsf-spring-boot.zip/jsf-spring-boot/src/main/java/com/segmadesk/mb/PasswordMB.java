package com.segmadesk.mb;

import java.io.Serializable;
import java.sql.SQLException;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.view.ViewScoped;
import javax.faces.context.FacesContext;
import javax.faces.context.Flash;

import org.primefaces.PrimeFaces;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.segmadesk.dto.StoreProcedureReturn;
import com.segmadesk.dto.UserRolesManage;
import com.segmadesk.model.AppUsers;
import com.segmadesk.service.UserLoginServiceImpl;
import com.segmadesk.util.Constants;
import com.segmadesk.util.HttpUtility;
import com.segmadesk.util.SegmaException;


@Component("passwordReset")
@Scope("view")

public class PasswordMB implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String password;

	private String oldPassword;

	private String repeatPassword;



	@Autowired
	private UserLoginServiceImpl appUserObj;

	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getRepeatPassword() {
		return repeatPassword;
	}


	public void setRepeatPassword(String repeatPassword) {
		this.repeatPassword = repeatPassword;
	}
	@PostConstruct
	void init(){
		password = new  String();
		oldPassword = new  String();
		repeatPassword = new  String();
	}

	public void submitPassword() throws SegmaException, SQLException{
		String response = "";


		FacesMessage msg = new FacesMessage();
		if (password.isEmpty() || repeatPassword.isEmpty()) {
			msg = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "Please provide password");

		} else {

			if (!password.equalsIgnoreCase(repeatPassword)) {
				response = "Sorry Password Mismatch";
				msg = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error",
						 response);

			} else {
				UserRolesManage roleManger = (UserRolesManage) HttpUtility
						.getSession(Constants.LOGIN_SESSION_KEY_USER);
				AppUsers cbrUserObj = roleManger.getUser();
				cbrUserObj.setPasswd(password);

				StoreProcedureReturn procedureReturn = appUserObj.ChangePassword(cbrUserObj.getUserid(), password,
						oldPassword);
				if (procedureReturn.getStatus().contains("S")) {
					msg = new FacesMessage(FacesMessage.SEVERITY_INFO, "Successful",
							"Password Changed Successfully");

				} else {
					cbrUserObj.setPasswd(oldPassword);
					response = procedureReturn.getDescription();
					msg = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error",
							response);

				}

			}
		}
		if (response == "") {
			// FacesContext.getCurrentInstance().addMessage("changePasswordMsg",
			// msg);
			// FacesContext context = FacesContext.getCurrentInstance();
			// context.getExternalContext().getFlash().setKeepMessages(true);

			FacesContext facesContext = FacesContext.getCurrentInstance();
			Flash flash = facesContext.getExternalContext().getFlash();
			flash.setKeepMessages(true);
			flash.setRedirect(true);
			facesContext.addMessage("resetPwdMsg", msg);
			PrimeFaces current = PrimeFaces.current();

			current.executeScript("PF('resetPwdDialog').show();");
			// return "logout.xhtml?faces-redirect=true";
		} else {
			FacesContext.getCurrentInstance().addMessage(null, msg);
			FacesContext context = FacesContext.getCurrentInstance();
			context.getExternalContext().getFlash().setKeepMessages(true);
			// return null;
		}


	}








	public String getOldPassword() {
		return oldPassword;
	}


	public void setOldPassword(String oldPassword) {
		this.oldPassword = oldPassword;
	}


	



	public String redirectLogout() {
		return "logout.xhtml?faces-redirect=true";
	}


	


}
