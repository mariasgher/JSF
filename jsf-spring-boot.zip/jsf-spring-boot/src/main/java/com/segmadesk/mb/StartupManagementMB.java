package com.segmadesk.mb;

import java.io.Serializable;

import javax.faces.event.PhaseEvent;

import com.segmadesk.dto.UserRolesManage;
import com.segmadesk.util.Constants;
import com.segmadesk.util.HttpUtility;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;
import org.springframework.web.context.annotation.SessionScope;


@Component("startUpServer")
@SessionScope
public class StartupManagementMB implements Serializable{
	
	/**
	 * 
	 */
	 private static final Logger LOGGER = LogManager.getLogger(StartupManagementMB.class);
	private static final long serialVersionUID = -6303024277089280887L;

	public void beforePhase(PhaseEvent ev) {
		/*
		 * session expire check
		 */
		
		
		UserRolesManage adminObj;
		
		try {
			adminObj = null;
			String requestedURL = HttpUtility.getRequest().getRequestURI();
			adminObj = (UserRolesManage) 	HttpUtility.getSession(Constants.LOGIN_SESSION_KEY_USER);
			

			if (adminObj == null) {
				HttpUtility.redirect("login");
			} else if (adminObj.getUser() != null) {
				String status =adminObj.getUser().getStatus()+"";
				if(!status.equalsIgnoreCase(Constants.SegmaPassowrdUser.ActiveUser))
						if (!requestedURL.contains("resetPassword")) {
							HttpUtility.redirect("resetPassword.xhtml");
						}
			}

		
		} catch (Exception ex){
			LOGGER.error( this.getClass().getName() + ".beforePhase()", ex );
		}
	}
}
