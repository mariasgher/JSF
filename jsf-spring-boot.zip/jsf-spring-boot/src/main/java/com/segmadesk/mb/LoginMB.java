package com.segmadesk.mb;

import java.io.Serializable;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

import javax.faces.view.ViewScoped;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.primefaces.PrimeFaces;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.segmadesk.dto.StoreProcedureReturn;
import com.segmadesk.dto.UserRolesManage;
import com.segmadesk.model.AppRoleFunctions;
import com.segmadesk.model.AppSysFunctions;
import com.segmadesk.model.AppSysModules;
import com.segmadesk.model.AppSysRoles;
import com.segmadesk.model.AppUserRoles;
import com.segmadesk.model.AppUserRolesId;
import com.segmadesk.model.AppUsers;
import com.segmadesk.service.FunctionsServiceImpl;
import com.segmadesk.service.ModuleServiceImpl;
import com.segmadesk.service.UserLoginServiceImpl;
import com.segmadesk.util.Constants;
import com.segmadesk.util.HttpUtility;
import com.segmadesk.util.SegmaException;


@Component("login")
@ViewScoped
public class LoginMB implements Serializable {

	

	@Autowired
	private UserLoginServiceImpl appUserObj;

	

	/**
	 * 
	 */
	 private static final Logger LOGGER = LogManager.getLogger(LoginMB.class);
	private static final long serialVersionUID = -2443130775868265477L;
	private String userName;
	private String password;
	private String host;
	private String nextPage = "";
	private String message;
	private String color;
	private String loginMsg="";




	public LoginMB() {
		System.out.println("login created!");
		userName = "";
		password = "";
		message = "";
	}

	public String login() {
		try {

			LOGGER.trace("userName : " + userName);

			
				userName = userName.toUpperCase();
				StoreProcedureReturn storeProcedureReturn = new StoreProcedureReturn();
				
				
				storeProcedureReturn.setStatus("S");
				storeProcedureReturn.setDescription("Successful logged in");
				//StoreProcedureReturn storeProcedureReturn =
				//		 appUserObj.firstTimeLogin(userName, password);
				if (storeProcedureReturn.getStatus().equalsIgnoreCase("E")
						|| storeProcedureReturn.getStatus().equalsIgnoreCase("S")) {

					AppUsers appUsers = appUserObj.getAppUsers(userName);
					Set<AppUserRoles> test = appUsers.getAppUserRoleses();
					for (AppUserRoles test1 : test) {
						AppSysRoles app = test1.getAppSysRoles();
						Set<AppRoleFunctions> test2 = app.getAppRoleFunctionses();
						for (AppRoleFunctions test3 : test2) {
							test3.getAppSysFunctions();
							test3.getAppSysRoles();

						}
					}
				
					/**
					 * get modules against users
					 */
					UserRolesManage roleManger = new UserRolesManage();

					roleManger.setUser(appUsers);
					Iterator<AppUserRoles> itr = appUsers.getAppUserRoleses().iterator();
					Set<AppSysRoles> userRoleSet = new HashSet<>();
					Set<AppSysFunctions> userRolePagesSet = new HashSet<>();
					Set<AppSysModules> userRoleModuleSet = new HashSet<>();
					while (itr.hasNext()) { // get roles
						AppUserRoles appUserRoles = (AppUserRoles) itr.next();
						LOGGER.trace(
								appUsers.getUserid() + " Role :" + appUserRoles.getAppSysRoles().getId().getRoleId());
						// for userRole
						if (appUserRoles.getActive().equals("A")) {
							userRoleSet.add(appUserRoles.getAppSysRoles());

							/** check for adduser **/
							if (appUserRoles.getAppSysRoles().getId().getRoleId()
									.equalsIgnoreCase(Constants.ADD_USER_AUTHORITY)) {
								roleManger.setUserrole(true);
							}
							Iterator<AppRoleFunctions> itrRolePage = appUserRoles.getAppSysRoles()
									.getAppRoleFunctionses().iterator();
							while (itrRolePage.hasNext()) { // get roles against pages
								AppRoleFunctions appRoleFunctions = (AppRoleFunctions) itrRolePage.next();
								LOGGER.trace(appUsers.getUserid() + " ------ Pages: "
										+ appRoleFunctions.getAppSysFunctions().getId().getPageId());
								// for roleFunction
								if (appRoleFunctions.getAppSysRoles().getActive()
										.equalsIgnoreCase(Constants.SegmaStatus.ActiveUser)) {
									if (appRoleFunctions.getActive().equals("A")) {
										userRolePagesSet.add(appRoleFunctions.getAppSysFunctions());
										userRoleModuleSet.add(appRoleFunctions.getAppSysFunctions().getAppSysModules());
									}
									userRolePagesSet.add(appRoleFunctions.getAppSysFunctions());
									userRoleModuleSet.add(appRoleFunctions.getAppSysFunctions().getAppSysModules());
								}
							}
						}
					}
					roleManger.setUser(appUsers);
					roleManger.setRoles(userRoleSet);
					TreeSet<AppSysModules> treeSetModules = new TreeSet<AppSysModules>();
					treeSetModules.addAll(userRoleModuleSet);
					roleManger.setModules(treeSetModules);
					TreeSet<AppSysFunctions> treeSetPages = new TreeSet<AppSysFunctions>();
					treeSetPages.addAll(userRolePagesSet);
					for (AppSysFunctions appSysFunctions : treeSetPages) {
						
						if(appSysFunctions.getId().getPageId().equalsIgnoreCase("addUser.xhtml"))						
						appSysFunctions.getId().setPageId("ui/"+appSysFunctions.getId().getPageId());
						else
						appSysFunctions.getId().setPageId("ui/"+appSysFunctions.getId().getPageId());
					}
					roleManger.setPages(new TreeSet<>(treeSetPages));

					/**
					 * creating banner
					 */
					Map<AppSysModules, List<AppSysFunctions>> bannerMap = new TreeMap<>();
					for (Iterator iterator = userRolePagesSet.iterator(); iterator.hasNext();) {
						AppSysFunctions appFunctions = (AppSysFunctions) iterator.next();
						List<AppSysFunctions> appfuntionLst = new ArrayList<>();
						if (bannerMap.get(appFunctions.getAppSysModules()) != null) { // is not empty
							List<AppSysFunctions> uploadExistingfuntionLst = bannerMap
									.get(appFunctions.getAppSysModules());
							uploadExistingfuntionLst.add(appFunctions);
						} else { // is empty
							appfuntionLst.add(appFunctions);
							bannerMap.put(appFunctions.getAppSysModules(), appfuntionLst);
						}
					}

					/** end of code */

					for (Map.Entry<AppSysModules, List<AppSysFunctions>> entry : bannerMap.entrySet()) {
						AppSysModules appModules = entry.getKey();
						List<AppSysFunctions> appFunction = entry.getValue();
						appModules.setAppSysFunctionses(new TreeSet<AppSysFunctions>(appFunction));
					}
					/**
					 * end of modules
					 */
					HttpUtility.setSession(Constants.LOGIN_SESSION_KEY_USER, roleManger);
					/**
					 * end of modules
					 */
					storeProcedureReturn.setUserName(userName);
					HttpUtility.setSession(Constants.LOGIN_SESSION_KEY_USER_DESC, storeProcedureReturn);
					PrimeFaces current = PrimeFaces.current();

					current.executeScript("PF('loginConfirmDialogVar').show();");
					return "true";

				}

				else {
					setMessage(storeProcedureReturn.getDescription());
					setColor("red");
				}
			
		} catch (Exception e) {
			LOGGER.error(e);
		}
		return "false";

	}
	public void redirectPageToDasboard() {

		StoreProcedureReturn storeProcedureReturn;
		try {
			storeProcedureReturn = (StoreProcedureReturn) HttpUtility.getSession(Constants.LOGIN_SESSION_KEY_USER_DESC);

			if(storeProcedureReturn.getStatus().equalsIgnoreCase("E"))
				HttpUtility.redirect("resetPassword.xhtml");
			else
				HttpUtility.redirect("dashboard.xhtml");

		} catch (SegmaException e) {
			LOGGER.error(e);
			e.printStackTrace();
		}
	}


	public String getLoginMsg() {

		try {
			StoreProcedureReturn	storeProcedureReturn = (StoreProcedureReturn) HttpUtility.getSession(Constants.LOGIN_SESSION_KEY_USER_DESC);
			if(storeProcedureReturn!=null){
				loginMsg = storeProcedureReturn.getDescription();
			}
			else{
				loginMsg="";
			}

		} catch (SegmaException e) {
			e.printStackTrace();
		}
		return loginMsg;

	}



	
	private final Charset UTF8_CHARSET = Charset.forName("UTF-8");

	String decodeUTF8(byte[] bytes) {
		return new String(bytes, UTF8_CHARSET);
	}

	byte[] encodeUTF8(String string) {
		return string.getBytes(UTF8_CHARSET);
	}
	/**
	 * 
	 * @return ubpsUserdao
	 */



	public void setLoginMsg(String loginMsg) {
		this.loginMsg = loginMsg;
	}


	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}



	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public String getNextPage() {
		return nextPage;
	}

	public void setNextPage(String nextPage) {
		this.nextPage = nextPage;
	}


}
