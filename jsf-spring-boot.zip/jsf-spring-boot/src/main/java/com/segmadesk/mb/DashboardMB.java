package com.segmadesk.mb;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.view.ViewScoped;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.segmadesk.dto.UserRolesManage;
import com.segmadesk.model.AppSysFunctions;
import com.segmadesk.model.AppSysModules;
import com.segmadesk.util.Constants;
import com.segmadesk.util.HttpUtility;
import com.segmadesk.util.SegmaException;



@Component("dashboardMB")
@Scope("view")
public class DashboardMB implements Serializable {

	/**
	 * 
	 */
	 private static final Logger LOGGER = LogManager.getLogger(DashboardMB.class);
	private static final long serialVersionUID = -919930837742061685L;
	private String populateDashBoardScreen;


	private List<AppSysModules> module= new ArrayList<>();

	private List<AppSysFunctions> functions = new ArrayList<>();

	private AppSysModules selectedModule;

	private int toggle=-1;


	@PostConstruct
	public void init() {
		toggle=-1;
		try {
			UserRolesManage ubpsUsers = (UserRolesManage) HttpUtility.getSession(Constants.LOGIN_SESSION_KEY_USER);
			if(ubpsUsers!=null){
				if(ubpsUsers.getModules()!=null) {
					module.addAll(new ArrayList<>(ubpsUsers.getModules()));
					Collections.sort(module);
				}
			}

		} catch (SegmaException e) {
			// TODO Auto-generated catch block
			LOGGER.error(this.getClass().getName() + "init", e);
		}
	}

	public AppSysModules getSelectedModule() {

		return selectedModule;
	}
	
	public void setSelectedModule(AppSysModules selectedModule) {
		this.selectedModule = selectedModule;
		List functions = new ArrayList<>();
		int toggle;
		try {
			if(selectedModule!=null){

				UserRolesManage ubpsUsers = (UserRolesManage) HttpUtility.getSession(Constants.LOGIN_SESSION_KEY_USER);
				Iterator itr= ubpsUsers.getPages().iterator();
				while (itr.hasNext()) {
					AppSysFunctions objPage = (AppSysFunctions) itr.next();
					/**
					 * add module pages with in specific role
					 */
					if(selectedModule.getId().getModuleId().equalsIgnoreCase(objPage.getAppSysModules().getId().getModuleId())){
						functions.add(objPage);   
					}
				}
				//Collections.sort( functions);
				Collections.sort(functions);

				//Collections.toggle=1;
			}
		} catch (SegmaException e) {
			// TODO Auto-generated catch block
			LOGGER.error(this.getClass().getName() + "selectedmod", e);

		}
	}
	



	public int getToggle() {
		return toggle;
	}

	public void setToggle(int toggle) {
		this.toggle = toggle;
	}

	

	public String getPopulateDashBoardScreen() {

	
		return populateDashBoardScreen;
	}

	public List<AppSysModules> getModule() {
		return module;
	}

	public void setModule(List<AppSysModules> module) {
		this.module = module;
	}

	public List<AppSysFunctions> getFunctions() {
		return functions;
	}

	public void setFunctions(List<AppSysFunctions> functions) {
		this.functions = functions;
	}

	
	
}
