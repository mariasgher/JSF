package com.segmadesk.mb;

import java.io.Serializable;
import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.segmadesk.dto.ApplicationDtoList;
import com.segmadesk.dto.ApplicationRolesDto;
import com.segmadesk.dto.StoreProcedureReturn;
import com.segmadesk.model.AppSysRoles;
import com.segmadesk.model.AppSystems;
import com.segmadesk.model.AppUserRoles;
import com.segmadesk.model.AppUserRolesId;
import com.segmadesk.model.AppUsers;
import com.segmadesk.service.CommonServiceImpl;
import com.segmadesk.service.RoleServiceImpl;
import com.segmadesk.service.SystemServiceImpl;
import com.segmadesk.service.UserLoginServiceImpl;
import com.segmadesk.util.Constants;
import com.segmadesk.util.HttpUtility;
import com.segmadesk.util.SegmaException;
import com.segmadesk.util.ToUpperCase;

@Component("idCreationMB")
@Scope("view")
public class UserManagementMB implements Serializable {
	/**
	 * 
	 */
	private static final Logger LOGGER = LogManager.getLogger(LoginMB.class);

	@Autowired
	private RoleServiceImpl appRolesObj;

	@Autowired
	private CommonServiceImpl commonFunctionObj;

	@Autowired
	private SystemServiceImpl systemServiceObj;



	@Autowired
	private UserLoginServiceImpl appUserObj;

	private static final long serialVersionUID = -6657559080934167565L;
	private String addUser;
	private String userid;

	private String ubpsBranch;
	private Map<String, String> branches = new LinkedHashMap<String, String>();
	private Map<String, String> systemApplication = new LinkedHashMap<String, String>();
	private Map<String, String> employeeType = new LinkedHashMap<String, String>();
	private List<AppUsers> userlst = new ArrayList<>();
	private List<AppUsers> allUserlst = new ArrayList<>();
	private List<AppUsers> rejUserlst = new ArrayList<>();

	private List<AppUsers> filterUserLst = new ArrayList<>();
	private AppUsers userEditObj;
	private AppUsers userObj;
	private String selDesig;
	private List<ApplicationDtoList> userRoleList;
	private List<ApplicationRolesDto> selectedUserRoleList;

	private Set<AppUserRoles> selectedRolesList;

	private String roleEditString;
	private String[] editUserRole;
	private boolean editUser = false;
	private AppUsers resetPassword;
	private String[] selSystem;
	private String dialogLabel;
	private List<AppUsers> userPendinglst = new ArrayList<>();

	private String branchId;

	// onLoad method
	@PostConstruct
	public void init() {
		try {
			StoreProcedureReturn manage = (StoreProcedureReturn) HttpUtility
					.getSession(Constants.LOGIN_SESSION_KEY_USER_DESC);
			if (manage != null) {
				userObj = new AppUsers();

			
				List systemlst = systemServiceObj.getAllSystem();
				for (Iterator systemItr = systemlst.iterator(); systemItr.hasNext();) {
					AppSystems systemSystem = (AppSystems) systemItr.next();
					systemApplication.put(systemSystem.getAppId() + "-" + systemSystem.getAppName(),
							systemSystem.getAppId());
				}

				employeeType.put("Permanent", "E");
				employeeType.put("Contract", "C");

				userlst = appUserObj.getUsersNotCreatedBy(manage.getUserName());
				userPendinglst = appUserObj.pendingUsers(manage.getUserName());
				allUserlst = appUserObj.allUsers();
				rejUserlst = appUserObj.rejUsers(manage.getUserName());

			} else {
				HttpUtility.redirect("login");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public String getDialogLabel() {
		if (editUser == true)
			return "Approve User";
		else
			return "Edit User";

	}


	public void setUserEditObj(AppUsers userEditObj) throws Exception {
		if (userEditObj != null) {
			if (userEditObj.getVerSts() == null)
				userObj.setStatus(Constants.SegmaStatus.ActiveUser);
			else
				userObj.setStatus(userEditObj.getVerSts().toString());

			StoreProcedureReturn adminObj = (StoreProcedureReturn) HttpUtility
					.getSession(Constants.LOGIN_SESSION_KEY_USER_DESC);
			boolean userCanEdit = false;
			if (userEditObj.getVerSts().equals(Constants.SegmaMakerCheckerStatus.NewUser)
					|| userEditObj.getVerSts().equals(Constants.SegmaMakerCheckerStatus.Updated))
				if (userEditObj.getInputBy().equalsIgnoreCase(adminObj.getUserName())) {
					userCanEdit = true;
				} else
					userCanEdit = false;

			else if (userEditObj.getVerSts().equals(Constants.SegmaMakerCheckerStatus.Approve)) {
				/*
				 * if(userEditObj.getInputBy().equalsIgnoreCase(adminObj.getApplicationBanner().
				 * getUserId())) { editUser=false; } else
				 */ userCanEdit = true;
			} else if (userEditObj.getVerSts().equals(Constants.SegmaMakerCheckerStatus.Reject)
					|| userEditObj.getVerSts().equals(Constants.SegmaMakerCheckerStatus.EditUser)) {
				if (userEditObj.getInputBy().equalsIgnoreCase(adminObj.getUserName())) {
					userCanEdit = true;
				} else {
					userCanEdit = false;
				}

			}
			editUser = !userCanEdit;
			this.userEditObj = userEditObj;
			userEditObj.setVerSts(Constants.SegmaMakerCheckerStatus.Approve);
		} else {
			this.userEditObj = userEditObj;
		}
	}

	/**
	 * 
	 * @return ubpsUserdao
	 */

	public void updateUser() throws Exception {
		StoreProcedureReturn userRolesMang = (StoreProcedureReturn) HttpUtility
				.getSession(Constants.LOGIN_SESSION_KEY_USER_DESC);


		userEditObj.setInputBy(userRolesMang.getUserName());
		userEditObj.setActive(Constants.SegmaStatus.InActive);

		userEditObj.setVerSts(Constants.SegmaMakerCheckerStatus.EditUser);

		FacesMessage msg = null;

		try {

			userEditObj.setActive(Constants.SegmaStatus.InActive);

			StoreProcedureReturn userRolesManage = (StoreProcedureReturn) HttpUtility
					.getSession(Constants.LOGIN_SESSION_KEY_USER_DESC);
			
			userEditObj.setInputBy(userRolesManage.getUserName());
			userEditObj.setInputDate(new Date());

		

			StoreProcedureReturn manage = ((StoreProcedureReturn) HttpUtility
					.getSession(Constants.LOGIN_SESSION_KEY_USER_DESC));
			if (manage != null) {
				commonFunctionObj.updateUser(ToUpperCase.pojotToUpperCase(userEditObj));
				userlst = appUserObj.getUsersNotCreatedBy(manage.getUserName());
				userPendinglst = appUserObj.pendingUsers(manage.getUserName());
				rejUserlst = appUserObj.rejUsers(manage.getUserName());

				msg = new FacesMessage(FacesMessage.SEVERITY_INFO, "valid-" + "" + userEditObj.getUserid(),
						" User Modified Successfully");
			} else {
				msg = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Invalid- Session Expired", "Session Expire");
			}

			// }

		} catch (Exception e) {
			msg = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Invalid - Unable To Add User", "unable to add user");
		} finally {
			if (msg != null) {
				FacesContext.getCurrentInstance().addMessage(null, msg);
			}

		}

	}

	

	public void submitUser() {
		FacesMessage msg = null;
		// AppUsers appUsers = new AppUsers();
		try {
			StoreProcedureReturn userSession = (StoreProcedureReturn) HttpUtility
					.getSession(Constants.LOGIN_SESSION_KEY_USER_DESC);

			if (userObj.getEmail().contains("@") || userObj.getEmail().contains(".com")) {
				msg = new FacesMessage(FacesMessage.SEVERITY_ERROR,
						"Invalid - Email @ Not Allowed, Only Provide Email Name",
						"Email @ Not Allowed, Only Provide Email Name");
			}

			else if (userSession != null) {

				userObj.setUserid(userObj.getUsername());

				userObj.setEmail(userObj.getEmail() );

				String securePasswd = new BigInteger(40, new SecureRandom()).toString(30);
				userObj.setPasswd(securePasswd);
				userObj.setActive(Constants.SegmaStatus.InActive);

			
				userObj.setAppUserRoleses(selectedRolesList);
				userObj.setInputBy(userSession.getUserName());
				userObj.setInputDate(new Date());
				userObj.setVerSts(Constants.SegmaMakerCheckerStatus.NewUser);

				List<AppUserRoles> roleuserlst = new ArrayList<AppUserRoles>();
				

				if (appUserObj.isUsernameExist(userObj.getUsername())) {
					msg = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Invalid - Employee Already Exist ",
							"Employee Already Exist");
				} else {
					for (ApplicationDtoList selectedApp : userRoleList) {
						List<AppSysRoles> lst = appRolesObj.getAllAppRolesAgainstApplication(selectedApp.getAppId());
						AppSysRoles sysRoles = (!lst.isEmpty()) ? lst.get(0) : new AppSysRoles();
						for (ApplicationRolesDto selectedRoles : selectedApp.getSelectedapplicationDtoLst()) {

							AppUserRoles rolesUser = new AppUserRoles();
							rolesUser.setActive(Constants.SegmaStatus.InActive);
							rolesUser.setAppUsers(userObj);

							rolesUser.setInputBy(userSession.getUserName());
							rolesUser.setInputDate(new Date());
							rolesUser.setVerSts(Constants.SegmaMakerCheckerStatus.NewUser);
							rolesUser.setAppSysRoles(sysRoles);
							AppUserRolesId appUserRolesId = new AppUserRolesId();
							appUserRolesId.setRoleId(selectedRoles.getRoleId());
							appUserRolesId.setUserId(userObj.getUserid());
							appUserRolesId.setAppId(selectedRoles.getAppId());
							rolesUser.setId(appUserRolesId);
							roleuserlst.add(rolesUser);

						}
					}

					commonFunctionObj.saveMultipleObject(ToUpperCase.pojotToUpperCase(userObj), roleuserlst);

					userlst = appUserObj.getUsersNotCreatedBy(userSession.getUserName());
					userPendinglst = appUserObj.pendingUsers(userSession.getUserName());
					msg = new FacesMessage(FacesMessage.SEVERITY_INFO, "Valid  - Added Successfully",
							userObj.getUserid() + " Created Successfully");
					userObj = new AppUsers();
				}

			} else {
				HttpUtility.redirect("login");
			}
		} catch (Exception e) {
			userObj.setEmail(userObj.getEmail());
			LOGGER.error(e.getMessage());
			e.printStackTrace();
			msg = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Invalid", "unable to add user");
		}

		if (msg != null) {
			FacesContext.getCurrentInstance().addMessage(null, msg);
		}

	}

	public List<AppUsers> getFilterUserLst() {
		return filterUserLst;
	}

	public void setFilterUserLst(List<AppUsers> filterUserLst) {
		this.filterUserLst = filterUserLst;
	}

	public void resetPasswordfn() {

		LOGGER.info("reset password");

	}

	public AppUsers getResetPassword() {
		return resetPassword;
	}

	public void blockUser() {
		FacesMessage msg = null;
		try {
			StoreProcedureReturn manage = ((StoreProcedureReturn) HttpUtility
					.getSession(Constants.LOGIN_SESSION_KEY_USER_DESC));
			if (manage != null) {
				appUserObj.blockUser(ToUpperCase.pojotToUpperCase(userEditObj), manage.getUserName());
				msg = new FacesMessage(FacesMessage.SEVERITY_INFO, "User", "Block Successfully");
				userlst = appUserObj.getUsersNotCreatedBy(manage.getUserName());
				userPendinglst = appUserObj.pendingUsers(manage.getUserName());
			} else {
				msg = new FacesMessage(FacesMessage.SEVERITY_WARN, "Referesh Pages", "Login Again");
			}
		} catch (SegmaException e) {
			msg = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Unable To block User ",
					"Please Contact Administrator..");
		} finally {
			if (msg != null) {
				FacesContext.getCurrentInstance().addMessage(null, msg);
			}
		}
	}

	public void setResetPassword(AppUsers resetPassword) {
		this.resetPassword = resetPassword;
		FacesMessage msg = null;
		try {
			StoreProcedureReturn procedure = appUserObj.SendEmail(resetPassword.getUserid(), "R");
			msg = new FacesMessage(FacesMessage.SEVERITY_INFO, procedure.getDescription(), procedure.getDescription());

		} catch (Exception e) {
			msg = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Invalid -Unable To Send Email",
					"Unable To Send Email");
		}
		if (msg != null) {
			FacesContext.getCurrentInstance().addMessage(null, msg);
		}
	}

	public void onSystemChange() {
		try {
			userRoleList = new ArrayList<>();

			for (String systemId : selSystem) {
				String appName = new String();
				List<AppSysRoles> roleslst = new ArrayList<AppSysRoles>();

				roleslst = appRolesObj.getAllAppRolesAgainstApplication(systemId);
				List<ApplicationRolesDto> dtoList = new ArrayList<>();
				List<ApplicationRolesDto> dtoListSelected = new ArrayList<>();
				for (AppSysRoles sysRoles : roleslst) {
					appName = sysRoles.getAppSystems().getAppName();
					dtoList.add(new ApplicationRolesDto(sysRoles.getId().getRoleId(), sysRoles.getId().getAppId(),
							sysRoles.getRoleName(), sysRoles.getRoleType(), sysRoles.getActive(), sysRoles.getInputBy(),
							sysRoles.getInputDate()));

				}
				userRoleList.add(new ApplicationDtoList(appName, systemId, dtoList, dtoListSelected));

			}

		} catch (SegmaException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void addSelectedApproles(ApplicationDtoList list) {

		System.out.println(list);

	}

	public void viewSelectedApproles() {
	}

	public String manageBranches() {
		return "addReconBranch.xhtml";
	}

	public List<ApplicationDtoList> getUserRoleList() {
		return userRoleList;
	}

	public void setUserRoleList(List<ApplicationDtoList> userRoleList) {
		this.userRoleList = userRoleList;
	}

	public List<ApplicationRolesDto> getSelectedUserRoleList() {
		return selectedUserRoleList;
	}

	public void setSelectedUserRoleList(List<ApplicationRolesDto> selectedUserRoleList) {
		this.selectedUserRoleList = selectedUserRoleList;
	}

	public Set<AppUserRoles> getSelectedRolesList() {
		return selectedRolesList;
	}

	public void setSelectedRolesList(Set<AppUserRoles> selectedRolesList) {
		this.selectedRolesList = selectedRolesList;
	}

	public Map<String, String> getEmployeeType() {
		return employeeType;
	}

	public void setEmployeeType(Map<String, String> employeeType) {
		this.employeeType = employeeType;
	}

	public String getAddUser() {
		return addUser;
	}

	public void setAddUser(String addUser) {
		this.addUser = addUser;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getUbpsBranch() {
		return ubpsBranch;
	}

	public void setUbpsBranch(String ubpsBranch) {
		this.ubpsBranch = ubpsBranch;
	}

	public Map<String, String> getBranches() {
		return branches;
	}

	public void setBranches(Map<String, String> branches) {
		this.branches = branches;
	}

	public List<AppUsers> getUserPendinglst() {
		return userPendinglst;
	}

	public void setUserPendinglst(List<AppUsers> userPendinglst) {
		this.userPendinglst = userPendinglst;
	}

	public AppUsers getUserObj() {
		return userObj;
	}

	public void setUserObj(AppUsers userObj) {
		this.userObj = userObj;
	}

	public String getSelDesig() {
		return selDesig;
	}

	public void setSelDesig(String selDesig) {
		this.selDesig = selDesig;
	}

	public String[] getSelSystem() {
		return selSystem;
	}

	public void setSelSystem(String[] selSystem) {
		this.selSystem = selSystem;
	}

	public Map<String, String> getSystemApplication() {
		return systemApplication;
	}

	public void setSystemApplication(Map<String, String> systemApplication) {
		this.systemApplication = systemApplication;
	}

	public String[] getEditUserRole() {
		return editUserRole;
	}

	public String getRoleEditString() {
		return roleEditString;
	}

	public void setRoleEditString(String roleEditString) {
		this.roleEditString = roleEditString;
	}

	public void setEditUserRole(String[] editUserRole) {

		this.editUserRole = editUserRole;
	}

	public List<AppUsers> getUserlst() {
		return userlst;
	}

	public void setUserlst(List<AppUsers> userlst) {
		this.userlst = userlst;
	}

	public boolean isEditUser() {
		return editUser;
	}

	public void setEditUser(boolean editUser) {
		this.editUser = editUser;
	}

	public AppUsers getUserEditObj() {

		return userEditObj;
	}

	public List<AppUsers> getAllUserlst() {
		return allUserlst;
	}

	public void setAllUserlst(List<AppUsers> allUserlst) {
		this.allUserlst = allUserlst;
	}

	public List<AppUsers> getRejUserlst() {
		return rejUserlst;
	}

	public void setRejUserlst(List<AppUsers> rejUserlst) {
		this.rejUserlst = rejUserlst;
	}

	public RoleServiceImpl getAppRolesObj() {
		return appRolesObj;
	}

	public void setAppRolesObj(RoleServiceImpl appRolesObj) {
		this.appRolesObj = appRolesObj;
	}

	public CommonServiceImpl getCommonFunctionObj() {
		return commonFunctionObj;
	}

	public void setCommonFunctionObj(CommonServiceImpl commonFunctionObj) {
		this.commonFunctionObj = commonFunctionObj;
	}

	public SystemServiceImpl getSystemServiceObj() {
		return systemServiceObj;
	}

	public void setSystemServiceObj(SystemServiceImpl systemServiceObj) {
		this.systemServiceObj = systemServiceObj;
	}


	public UserLoginServiceImpl getAppUserObj() {
		return appUserObj;
	}

	public void setAppUserObj(UserLoginServiceImpl appUserObj) {
		this.appUserObj = appUserObj;
	}


	public String getBranchId() {
		return branchId;
	}

	public void setBranchId(String branchId) {
		this.branchId = branchId;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public void setDialogLabel(String dialogLabel) {
		this.dialogLabel = dialogLabel;
	}

}
