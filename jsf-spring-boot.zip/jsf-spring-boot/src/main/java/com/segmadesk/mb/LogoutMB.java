package com.segmadesk.mb;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;

import org.springframework.stereotype.Component;

import com.segmadesk.util.Constants;
import com.segmadesk.util.HttpUtility;

@Component("logout")
@ViewScoped
public class LogoutMB implements Serializable {


	private static final long serialVersionUID = 7337309560812429900L;
	private String redirect;
	private String applicationRedirect;
	private String changeDate;
	private String vmIp;
	private String redirectUrl;
	private String applicationRedirectForSessionDestory;




	public String getChangeDate() {
		vmIp = applicationRedirect;
		String startDate = new String();
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		startDate = dateFormat.format(date);
		date = new Date();
		date.setMinutes(date.getMinutes() - 2);
		startDate = new String();
		startDate = dateFormat.format(date);

	
		return changeDate;
	}

	public String getRedirectUrl(){
		String urlredirect="";

		ExternalContext tmpEC;
		Map sMap;
		tmpEC = FacesContext.getCurrentInstance().getExternalContext();
		sMap = tmpEC.getSessionMap();




		return urlredirect;
	}
	public void setRedirectUrl(String redirectUrl) {
		this.redirectUrl = redirectUrl;
	}

	public String getApplicationRedirect() {




		HttpUtility.redirect("/ui/login.xhtml");




		return applicationRedirect;
	}





	public String getApplicationRedirectForSessionDestory() {

		HttpUtility.redirect("/ui/login.xhtml");

		return applicationRedirect;
	}

	public String getRedirect() {
		try {
			HttpUtility.removeSession(Constants.LOGIN_SESSION_KEY_USER);
			FacesContext.getCurrentInstance().getExternalContext().invalidateSession();
		} catch (Exception e) {
			e.printStackTrace();
		}
		//for local
		HttpUtility.redirect("/ui/login.xhtml");
		//for UAT/Prod
		//HttpUtility.redirect(Constants.SERVER_MODULE_NAME+"/ui/login.xhtml");

		return redirect;
				
	}
	public void setApplicationRedirectForSessionDestory(
			String applicationRedirectForSessionDestory) {
		this.applicationRedirectForSessionDestory = applicationRedirectForSessionDestory;
	}

	public String getVmIp() {
		return vmIp;
	}

	public void setVmIp(String vmIp) {
		this.vmIp = vmIp;
	}

	/**
	 * @return the userDao
	 */


}
