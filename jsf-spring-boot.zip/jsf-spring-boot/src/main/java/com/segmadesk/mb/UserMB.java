package com.segmadesk.mb;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.view.ViewScoped;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.segmadesk.dto.AddUserPages;

@Component("user")
@Scope("view")
public class UserMB implements Serializable {
	/**
	 * 
	 */
	 private static final Logger LOGGER = LogManager.getLogger(UserMB.class);
	private static final long serialVersionUID = 4131949533053436141L;

	private List<AddUserPages> functions = new ArrayList<>();

	@PostConstruct
	public void populateUserPage() {

		// 1. User Creation

		AddUserPages addUserPages = new AddUserPages();
		addUserPages.setPageId("/ui/manageUser.xhtml");
		addUserPages.setFriendlyName("Add User");
		functions.add(addUserPages);

	

		// 3. All Users waiting for approval
		addUserPages = new AddUserPages();
		addUserPages.setPageId("/ui/allUsers.xhtml");
		addUserPages.setFriendlyName("All Users");
		functions.add(addUserPages);
		


		// 5. pending user waiting for approval
		addUserPages = new AddUserPages();
		addUserPages.setPageId("/ui/assignRole.xhtml");
		addUserPages.setFriendlyName("Assign Role");
		functions.add(addUserPages);
		// end
	


	}

	public List<AddUserPages> getFunctions() {
		return functions;
	}

	public void setFunctions(List<AddUserPages> functions) {
		this.functions = functions;
	}

}
