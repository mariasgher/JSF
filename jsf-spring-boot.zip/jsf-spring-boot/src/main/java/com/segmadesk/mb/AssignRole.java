package com.segmadesk.mb;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.primefaces.event.RowEditEvent;
import org.primefaces.event.TransferEvent;
import org.primefaces.model.DualListModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.segmadesk.dto.StoreProcedureReturn;
import com.segmadesk.model.AppRoleFunctions;
import com.segmadesk.model.AppSysFunctions;
import com.segmadesk.model.AppSysRoles;
import com.segmadesk.model.AppSystems;
import com.segmadesk.model.AppUserRoles;
import com.segmadesk.model.AppUsers;
import com.segmadesk.service.AppUserRolesLoginServiceImpl;
import com.segmadesk.service.CommonServiceImpl;
import com.segmadesk.service.FunctionsServiceImpl;
import com.segmadesk.service.RoleFunctionLoginServiceImpl;
import com.segmadesk.service.RoleServiceImpl;
import com.segmadesk.service.SystemServiceImpl;
import com.segmadesk.service.UserLoginServiceImpl;
import com.segmadesk.util.Constants;
import com.segmadesk.util.HttpUtility;
import com.segmadesk.util.SegmaException;
import com.segmadesk.util.ToUpperCase;


@Component("assignRoleMB")
@Scope("view")
public class AssignRole implements Serializable {

	/**
	 * 
	 */
	 private static final Logger logger = LogManager.getLogger(AssignRole.class);

	private static final long serialVersionUID = 3275727925220336803L;

	
	@Autowired
	private RoleServiceImpl appRolesObj;

	
	@Autowired
	private CommonServiceImpl commonFunctionObj;
	
	@Autowired
	private SystemServiceImpl systemServiceObj;
	

	
	
	@Autowired
	private RoleFunctionLoginServiceImpl appRoleFunctionObj;

	@Autowired
	private FunctionsServiceImpl appFunctionObj;

	@Autowired
	private UserLoginServiceImpl appUserObj;

	@Autowired
	private AppUserRolesLoginServiceImpl appUserRolesLoginObj;

	private Map<String, String> userRoles = new LinkedHashMap<String, String>();
	private String userRole;

	private List<AppSysFunctions> pagesList = new ArrayList<>();
	private List<AppUserRoles> alreadyaddedpagesList = new ArrayList<>();
	private List<AppSysFunctions> selectedPagesList = new ArrayList<>();
	private List<String> selectedPagesList1 = new ArrayList<>();
	// start
	List<String> pagesSource = new ArrayList<String>();
	List<String> pagesTarget = new ArrayList<String>();
	FacesMessage msg = null;
	private DualListModel<String> pages;
	private List<AppUserRoles> userRolesList = new ArrayList<>();

	private String userSessionId;
	private AppUserRoles roleRejectObj;
	private AppUserRoles userApproveObj;
	private AppRoleFunctions rolePagesActionObj;
	HashMap<String, AppUserRoles> roleFunctionRemrks = new HashMap<>();
	private String selSystem;
	private List<AppUsers> userlst = new ArrayList<>();
	private List<String> userIdlst = new ArrayList<>();

	
	private Map<String, String> systemApplication = new LinkedHashMap<String, String>();
	StoreProcedureReturn userRoleManage = null;
	private String selUserId;

	public String getUserSessionId() {
		return userSessionId;
	}

	public void setUserSessionId(String userSessionId) {
		this.userSessionId = userSessionId;
	}

	public String getUserRole() {
		return userRole;
	}

	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}

	public Map<String, String> getUserRoles() {
		return userRoles;
	}

	public void setUserRoles(Map<String, String> userRoles) {
		this.userRoles = userRoles;
	}

	public List<String> getSelectedPagesList1() {
		return selectedPagesList1;
	}

	public void setSelectedPagesList1(List<String> selectedPagesList1) {
		this.selectedPagesList1 = selectedPagesList1;
	}

	public List<AppSysFunctions> getPagesList() {
		return pagesList;
	}

	public void setPagesList(List<AppSysFunctions> pagesList) {
		this.pagesList = pagesList;
	}

	public List<AppSysFunctions> getSelectedPagesList() {
		return selectedPagesList;
	}

	public void setSelectedPagesList(List<AppSysFunctions> selectedPagesList) {
		this.selectedPagesList = selectedPagesList;
	}

	public DualListModel<String> getPages() {
		return pages;
	}

	public void setPages(DualListModel<String> pages) {
		this.pages = pages;
	}



	@PostConstruct
	void init() {
		pagesSource = new ArrayList<>();
		pagesTarget = new ArrayList<>();
		alreadyaddedpagesList= new ArrayList<>();
		FacesMessage msg = null;
		try {
			userRoleManage = (StoreProcedureReturn) HttpUtility.getSession(Constants.LOGIN_SESSION_KEY_USER_DESC);
			if (userRoleManage != null) {
				userlst = appUserObj.getUsersForRole(userRoleManage.getUserName());
				for (AppUsers user : userlst) {
					userIdlst.add(user.getUserid());
				}
				List systemlst = systemServiceObj.getAllSystem();
				for (Iterator systemItr = systemlst.iterator(); systemItr.hasNext();) {
					AppSystems systemSystem = (AppSystems) systemItr.next();
					systemApplication.put(systemSystem.getAppId() + "-" + systemSystem.getAppName(),
							systemSystem.getAppId());
				}

				fillPickList();
				allRolesPagesLsit();
			} else {
				HttpUtility.redirect("login");
			}
		} catch (Exception e) {
			msg = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Invalid", e.getMessage());
		}

		finally {
			if (msg != null) {
				FacesContext.getCurrentInstance().addMessage(null, msg);
			}
		}
	}

	public void onRowEdit(RowEditEvent event) {
		AppUserRoles entity = ((AppUserRoles) event.getObject());
		roleFunctionRemrks.put(entity.getId().getRoleId(), entity);

	}

	public void onRowCancel(RowEditEvent event) {

	}

	public void assignPages() {
		FacesMessage msg = null;
		try {
			if (selUserId == null) {
				msg = new FacesMessage(FacesMessage.SEVERITY_ERROR, "In Valid", "Role Required");

			} else if (selUserId.equalsIgnoreCase("-1")) {
				msg = new FacesMessage(FacesMessage.SEVERITY_ERROR, "In Valid", "Role Required");
			} else {

				StoreProcedureReturn manage = ((StoreProcedureReturn) HttpUtility
						.getSession(Constants.LOGIN_SESSION_KEY_USER_DESC));
				if (manage != null) {

					// List<String> selectedPages = pages.getTarget();
					appUserRolesLoginObj.saveUserRole(userRole, pages, manage, selSystem,selUserId);
					msg = new FacesMessage(FacesMessage.SEVERITY_INFO, "valid", "Role has been assigned to "+selUserId+"  Successfully");
				} else {
					msg = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Invalid", "unable to Add");
				}

			}
			allRolesPagesLsit();
		} catch (Exception e) {
			msg = new FacesMessage(FacesMessage.SEVERITY_ERROR, "In Valid", e.getMessage());
		} finally {
			if (msg != null) {
				FacesContext.getCurrentInstance().addMessage(null, msg);
			}
		}

	}

	public void onTransfer(TransferEvent event) {
		
        StringBuilder builder = new StringBuilder();
        for (Object item : event.getItems()) {
        	if(event.isAdd()) {
    			pagesTarget.add(item.toString());
    			pagesSource.remove(item.toString());
    		}
        	else {
        		pagesTarget.remove(item.toString());
    			pagesSource.add(item.toString());
        	}
          
        }

        FacesMessage msg = new FacesMessage();
        msg.setSeverity(FacesMessage.SEVERITY_INFO);
        msg.setSummary("Items Transferred");
        msg.setDetail(builder.toString());

        FacesContext.getCurrentInstance().addMessage(null, msg);
    }

	
	public void rolePagesAdded() {
		pagesTarget = new ArrayList<>();
		pagesSource = new ArrayList<>();
		fillPickList();
		try {

			alreadyaddedpagesList = appUserRolesLoginObj.getAppUserRolesAgainstApplication(selSystem, selUserId);

			for (AppUserRoles data : alreadyaddedpagesList) {
				pagesTarget.add(data.getId().getRoleId() );
				pagesSource.remove(data.getId().getRoleId());

			}
		} catch (SegmaException e) {
			e.printStackTrace();
		}

	}

	public void fillPickList() {
		List<AppSysRoles> roleslst = new ArrayList<>();
		try {

			if (selSystem != null && !selSystem.equals("")) {
				roleslst = appRolesObj.getAllAppRolesAgainstApplication(selSystem);
			}

			for (AppSysRoles data : roleslst) {
				// if
				pagesSource.add(data.getId().getRoleId());

			}
			setPages(new DualListModel<String>(pagesSource, pagesTarget));
		} catch (

		SegmaException e) {
			e.printStackTrace();
		}
	}

	public void allRolesPagesLsit() {
		FacesMessage msg = null;
		StoreProcedureReturn manage;
		setUserSessionId(null);
		try {
			manage = ((StoreProcedureReturn) HttpUtility.getSession(Constants.LOGIN_SESSION_KEY_USER_DESC));

			if (manage != null) {
				setUserSessionId(manage.getUserName());
				userRolesList=appUserRolesLoginObj.getAllInActiveUserRole(manage.getUserName());
			} else {
				msg = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Invalid", "Session Expire");
			}
		} catch (SegmaException e) {
			e.printStackTrace();
		} finally {
			if (msg != null) {
				FacesContext.getCurrentInstance().addMessage(null, msg);
			}
		}
	}

	public AppRoleFunctions getRolePagesActionObj() {
		return rolePagesActionObj;
	}

	public void setRolePagesActionObj(AppRoleFunctions rolePagesActionTempObj) {

		rolePagesActionObj = rolePagesActionTempObj;

	}

	public AppUserRoles getUserApproveObj() {
		return userApproveObj;
	}

	public void setUserApproveObj(AppUserRoles userApproveObj1) {
		if (Constants.SegmaMakerCheckerStatus.NewUser.equals(userApproveObj1.getVerSts())
				|| Constants.SegmaMakerCheckerStatus.EditUser.equals(userApproveObj1.getVerSts())
				|| Constants.SegmaMakerCheckerStatus.Reject.equals(userApproveObj1.getVerSts())) {

			FacesMessage msg = null;
			StoreProcedureReturn manage;
			try {
				manage = ((StoreProcedureReturn) HttpUtility.getSession(Constants.LOGIN_SESSION_KEY_USER_DESC));

				if (manage != null) {
					userApproveObj = userApproveObj1;
					if (userApproveObj1.getActive().equalsIgnoreCase(Constants.SegmaStatus.Block)) {

						userApproveObj.setActive(Constants.SegmaStatus.Block);

					} else {

						userApproveObj.setActive(Constants.SegmaStatus.ActiveUser);

						if (roleFunctionRemrks.get(userApproveObj.getId().getRoleId() + "-"
								+ userApproveObj.getId().getUserId()) != null) {
							userApproveObj.setRemarks(roleFunctionRemrks
									.get(userApproveObj.getId().getRoleId() + "-" + userApproveObj.getId().getUserId())
									.getRemarks());
							;
						}
					}

					userApproveObj.setVerBy(manage.getUserName());
					userApproveObj.setVerDate(new Date());
					userApproveObj.setVerSts(Constants.SegmaMakerCheckerStatus.Approve);
					commonFunctionObj.updateUserRole(ToUpperCase.pojotToUpperCase(userApproveObj));

					allRolesPagesLsit();
					msg = new FacesMessage(FacesMessage.SEVERITY_INFO, "valid", " Role Page Approve  Successfully");
				} else {
					msg = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Invalid", "Session Expire");
				}
			} catch (SegmaException e) {
				e.printStackTrace();
			} finally {
				if (msg != null) {
					FacesContext.getCurrentInstance().addMessage(null, msg);
				}
			}
		}
	}

	public AppUserRoles getRoleRejectObj() {
		return roleRejectObj;
	}

	public void setRoleRejectObj(AppUserRoles roleRejectObj1) {

		try {

			if (roleRejectObj1.getVerSts().equals(Constants.SegmaMakerCheckerStatus.NewUser)
					|| roleRejectObj1.getVerSts().equals(Constants.SegmaMakerCheckerStatus.EditUser)
					|| (roleRejectObj1.getVerSts().equals(Constants.SegmaMakerCheckerStatus.Approve))) {

				StoreProcedureReturn manage;

				manage = ((StoreProcedureReturn) HttpUtility.getSession(Constants.LOGIN_SESSION_KEY_USER_DESC));
				if (manage != null) {
					roleRejectObj = roleRejectObj1;
					

						roleRejectObj.setVerSts(Constants.SegmaMakerCheckerStatus.Reject);
						roleRejectObj.setActive(Constants.SegmaStatus.InActive);
						if (roleFunctionRemrks.get(
								roleRejectObj.getId().getRoleId() + "-" + roleRejectObj.getId().getUserId()) != null) {
							roleRejectObj.setRemarks(roleFunctionRemrks
									.get(roleRejectObj.getId().getRoleId() + "-" + roleRejectObj.getId().getUserId())
									.getRemarks());
							;
						}
					
					roleRejectObj.setVerBy(manage.getUserName());
					roleRejectObj.setVerDate(new Date());
					int result = appUserRolesLoginObj.rejectRole(roleRejectObj.getId().getRoleId(),roleRejectObj.getId().getAppId(),roleRejectObj.getId().getUserId());
					allRolesPagesLsit();
					msg = new FacesMessage(FacesMessage.SEVERITY_INFO, "valid", " Role Page Reject  Successfully");
				} else {
					msg = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Invalid", "Session Expire");
				}

			} else {
				msg = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Invalid", "Not Allowed to Reject Role");

			}

		}

		catch (SegmaException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (msg != null) {
				FacesContext.getCurrentInstance().addMessage(null, msg);
			}
		}
	}

	public void blockRolePages() {
		FacesMessage msg = null;
		try {
			StoreProcedureReturn manage = ((StoreProcedureReturn) HttpUtility
					.getSession(Constants.LOGIN_SESSION_KEY_USER_DESC));
			if (manage != null) {
				appRoleFunctionObj.blockRoleFunction(ToUpperCase.pojotToUpperCase(rolePagesActionObj),
						manage.getUserName());
				msg = new FacesMessage(FacesMessage.SEVERITY_INFO, "User", "Block Successfully");
				allRolesPagesLsit();
			} else {
				msg = new FacesMessage(FacesMessage.SEVERITY_WARN, "Referesh Pages", "Login Again");
			}
		} catch (SegmaException e) {
			msg = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Unable To block User ",
					"Please Contact Administrator..");
		} finally {
			if (msg != null) {
				FacesContext.getCurrentInstance().addMessage(null, msg);
			}
		}
	}

	public void onSystemChange() {
		try {
			userRoles.clear();
			if (selSystem != null && !selSystem.equals("")) {
				List roleslst = appRolesObj.getAllAppRolesAgainstApplication(selSystem);
				userRoles.put("Select Role", "-1");
				for (Iterator roleItr = roleslst.iterator(); roleItr.hasNext();) {
					AppSysRoles ubpsRoles = (AppSysRoles) roleItr.next();
					userRoles.put(ubpsRoles.getId().getRoleId(), ubpsRoles.getId().getRoleId());
				}
			}

		} catch (SegmaException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	

	public String getSelSystem() {
		return selSystem;
	}

	public void setSelSystem(String selSystem) {
		this.selSystem = selSystem;
	}

	public Map<String, String> getSystemApplication() {
		return systemApplication;
	}

	public void setSystemApplication(Map<String, String> systemApplication) {
		this.systemApplication = systemApplication;
	}

	public StoreProcedureReturn getUserRoleManage() {
		return userRoleManage;
	}

	public void setUserRoleManage(StoreProcedureReturn userRoleManage) {
		this.userRoleManage = userRoleManage;
	}

	

	public List<AppUserRoles> getAlreadyaddedpagesList() {
		return alreadyaddedpagesList;
	}

	public void setAlreadyaddedpagesList(List<AppUserRoles> alreadyaddedpagesList) {
		this.alreadyaddedpagesList = alreadyaddedpagesList;
	}

	public List<String> getPagesSource() {
		return pagesSource;
	}

	public void setPagesSource(List<String> pagesSource) {
		this.pagesSource = pagesSource;
	}

	public List<String> getPagesTarget() {
		return pagesTarget;
	}

	public void setPagesTarget(List<String> pagesTarget) {
		this.pagesTarget = pagesTarget;
	}

	public List<AppUsers> getUserlst() {
		return userlst;
	}

	public void setUserlst(List<AppUsers> userlst) {
		this.userlst = userlst;
	}

	

	public String getSelUserId() {
		return selUserId;
	}

	public void setSelUserId(String selUserId) {
		this.selUserId = selUserId;
	}

	public List<String> getUserIdlst() {
		return userIdlst;
	}

	public void setUserIdlst(List<String> userIdlst) {
		this.userIdlst = userIdlst;
	}

	public List<AppUserRoles> getUserRolesList() {
		return userRolesList;
	}

	public void setUserRolesList(List<AppUserRoles> userRolesList) {
		this.userRolesList = userRolesList;
	}

}
