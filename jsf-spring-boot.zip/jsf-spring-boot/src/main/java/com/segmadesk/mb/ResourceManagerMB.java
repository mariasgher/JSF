package com.segmadesk.mb;

import java.io.Serializable;
import java.text.MessageFormat;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

import org.springframework.stereotype.Component;
import org.springframework.web.context.annotation.SessionScope;
	

@Component("resourceManagerMB")
@SessionScope
public class ResourceManagerMB implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1244609505740533566L;
	public String getMsgFromBundle(String ResourceName,
			String ResourceKey, Object... paramvale) {

		String messageBundle = "com.resources.";
		String RequiredMessage = "";  
		MessageFormat messageFormat;
		String message = "";
		ResourceBundle bundle = null;
		try {

			bundle = ResourceBundle.getBundle(messageBundle.concat(ResourceName
					.toLowerCase()));

		} catch (MissingResourceException ex) {

			FacesContext.getCurrentInstance().addMessage(
					null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error",
							"No Resource Is found"));
		}
		try {
			RequiredMessage = bundle.getString(ResourceKey);
			if (paramvale == null) {
				message = RequiredMessage;
			} else {
				messageFormat = new MessageFormat(RequiredMessage);

				message = messageFormat.format(paramvale);
			}
		} catch (MissingResourceException ex) {
			FacesContext.getCurrentInstance().addMessage(
					null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error",
							"No Such Resource Key Is found"));
		}
		return message;

	}

}
