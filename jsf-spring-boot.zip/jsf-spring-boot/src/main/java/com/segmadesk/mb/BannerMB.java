package com.segmadesk.mb;
import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.event.PhaseEvent;
import javax.faces.view.ViewScoped;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.primefaces.event.SelectEvent;
import org.primefaces.model.menu.DefaultMenuModel;
import org.primefaces.model.menu.MenuModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.segmadesk.dto.UserRolesManage;
import com.segmadesk.model.AppSysFunctions;
import com.segmadesk.model.AppSysModules;
import com.segmadesk.service.CommonServiceImpl;
import com.segmadesk.util.Constants;
import com.segmadesk.util.HttpUtility;
import com.segmadesk.util.SegmaException;



@Component("banner")
@Scope("view")
public class BannerMB implements Serializable{

	/**
	 * 
	 */
	 private static final Logger LOGGER = LogManager.getLogger(BannerMB.class);
	private static final long serialVersionUID = 5903843406289466365L;
	/**
	 * 
	 */
	
	@Autowired
	private CommonServiceImpl commonFunctionObj;
	
	private MenuModel model ;
	private String  sysDate;
	private UserRolesManage userObj;
	private String populateMenu;
	private AppSysFunctions appFuction;
	private AppSysFunctions selectedAppFuction;
	private List<AppSysFunctions> allFunctions;
	private List<AppSysModules> lstModule;
	private AppSysModules selectedAppModule;
	
	
	@PostConstruct
	public void init() {
		allFunctions=new ArrayList<AppSysFunctions>();
		lstModule= new ArrayList<>();
		try {
			UserRolesManage appUsers = (UserRolesManage) HttpUtility.getSession(Constants.LOGIN_SESSION_KEY_USER);
			if(appUsers!=null){

				lstModule.addAll(new ArrayList<>(appUsers.getModules()));
				Collections.sort(lstModule);

			}
			model = new DefaultMenuModel();
			sysDate = "";
			for (AppSysModules appMod : lstModule) {/*
				//submenu
				DefaultSubMenu firstSubmenu = new DefaultSubMenu(appMod.getModuleId());

				Set<AppFunctions> moduleFunction =  appMod.getAppFunctionses();
				 

				for (AppFunctions appFunctions : moduleFunction) {

                   
                     allFunctions.add(appFunctions);
					DefaultMenuItem item = new DefaultMenuItem(appFunctions.getFriendlyName());
					item.setUrl(appFunctions.getPageId());
					item.setIcon("ui-icon-home");
					((MenuModel) firstSubmenu).addElement(item);
				}
				model.addElement(firstSubmenu);


			*/}
		} catch (SegmaException e) {
			// TODO Auto-generated catch block
			LOGGER.error(this.getClass().getName() + "init", e);
		}
	}
	public MenuModel getModel() {
		if(model.getElements().isEmpty()){
			init();
		}
		return model;
	}  

	
	 public List<AppSysFunctions> completeFunction(String query) {
		 
			//FunctionsServiceImpl service=new FunctionsServiceImpl();
		 	List<AppSysFunctions> filteredFunctions = new ArrayList<AppSysFunctions>();
	         
	        for (int i = 0; i < allFunctions.size(); i++) {
	        	AppSysFunctions current = allFunctions.get(i);
	            if(current.getId().getPageId().toLowerCase().startsWith(query)) {
	                filteredFunctions.add(current);
	            }
	        }	         
	        return filteredFunctions;
	    }	
	 
	public void reDirectToOtherPage(PhaseEvent ev) throws Exception{
	

		userObj = null; 
		String requestedURL =
				HttpUtility.getRequest().getRequestURI(); 
		try { 
			userObj = (UserRolesManage) HttpUtility
					.getSession(Constants.LOGIN_SESSION_KEY_USER); 
			if (userObj == null &&
					!requestedURL.equals("/"+ Constants.SERVER_MODULE_NAME+ "/login"))
			{ 
				HttpUtility.redirect("login");
			}
			
		} 
		catch (Exception ex) 
		{ 
			LOGGER.error(this.getClass().getName() + "reDirectToOtherPage()", ex);
		}
	}

	
	public UserRolesManage getUserObj() {

		try {
			userObj = (UserRolesManage) HttpUtility
					.getSession(Constants.LOGIN_SESSION_KEY_USER);
			/*	Admin	tempAdminObj=new AdminService().getAdmin(adminObj.getUsername(), adminObj.getPassword());
			 */	
		} catch (Exception e) {
			HttpUtility.redirect("login");
			LOGGER.error("Ön bannerMB URL", e);
		} 

		
	
		return userObj;
	}
	public void setUserObj(UserRolesManage userObj) {
		this.userObj = userObj;
	}
	public String getPopulateMenu() {
		return populateMenu;
		
		}
	public String getSysDate() {
		DateFormat df = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
		String reportDate = null;
		// Get the date today using Calendar object.
		Date today;
		try {
			today = commonFunctionObj.getSystemDate();
		    
		// Using DateFormat format method we can create a string 
		// representation of a date with the defined format.
			UserRolesManage userObj = (UserRolesManage) HttpUtility
					.getSession(Constants.LOGIN_SESSION_KEY_USER);
		
		 reportDate = df.format(today);
		
		} catch (SegmaException e) {
			e.printStackTrace();
		}   
	
		return sysDate= reportDate;
	
	}
	
	public void onRowSelect(SelectEvent event) {
        HttpUtility.redirect(((AppSysFunctions) event.getObject()).getId().getPageId());
    }
	
	
	public void setSysDate(String sysDate) {
		this.sysDate = sysDate;
	}
	public AppSysFunctions getAppFuction() {
		return appFuction;
	}
	public void setAppFuction(AppSysFunctions appFuction) {
		this.appFuction = appFuction;
	}
	public List<AppSysFunctions> getAllFunctions() {
		return allFunctions;
	}
	public void setAllFunctions(List<AppSysFunctions> allFunctions) {
		this.allFunctions = allFunctions;
	}
	public AppSysFunctions getSelectedAppFuction() {
		return selectedAppFuction;
	}
	public void setSelectedAppFuction(AppSysFunctions selectedAppFuction) {
		this.selectedAppFuction = selectedAppFuction;
	}
	public List<AppSysModules> getLstModule() {
		return lstModule;
	}
	public void setLstModule(List<AppSysModules> lstModule) {
		this.lstModule = lstModule;
	}
	public AppSysModules getSelectedAppModule() {
		return selectedAppModule;
	}
	public void setSelectedAppModule(AppSysModules selectedAppModule) {
		this.selectedAppModule = selectedAppModule;
	}
	
	
}
