package com.segmadesk.mb;

import java.io.Serializable;
import java.sql.SQLIntegrityConstraintViolationException;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.segmadesk.dto.StoreProcedureReturn;
import com.segmadesk.model.Customer;
import com.segmadesk.service.CustomerServiceImpl;
import com.segmadesk.util.Constants;
import com.segmadesk.util.HttpUtility;
import com.segmadesk.util.SegmaException;

@Component("customerMB")
@Scope("view")
public class CustomerMB implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3205059418140500177L;
	@Autowired
	private CustomerServiceImpl customerService;
	private Customer customer;

	// onLoad method
	@PostConstruct
	public void init() {
		try {
			StoreProcedureReturn manage = (StoreProcedureReturn) HttpUtility
					.getSession(Constants.LOGIN_SESSION_KEY_USER_DESC);
			System.out.print("init");
			if (manage != null) {
				customer = new Customer();
				System.out.print("init - manage");
			} else {
				HttpUtility.redirect("login");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void submit() {
		FacesMessage msg = null;
		try {
			System.out.print("submit");

			customerService.saveBean(customer);
			msg = new FacesMessage(FacesMessage.SEVERITY_INFO, "Valid",
					"Added Customer Successfully");
		} catch (SQLIntegrityConstraintViolationException | SegmaException e) {
			e.printStackTrace();
			msg = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Invalid", e.getMessage());

		}
		if (msg != null) {
			FacesContext.getCurrentInstance().addMessage(null, msg);
		}
	}

	public CustomerServiceImpl getCustomerService() {
		return customerService;
	}

	public void setCustomerService(CustomerServiceImpl customerService) {
		this.customerService = customerService;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

}
