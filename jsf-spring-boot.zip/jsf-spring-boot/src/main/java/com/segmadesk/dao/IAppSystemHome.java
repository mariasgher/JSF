package com.segmadesk.dao;

import java.util.List;

import com.segmadesk.model.AppSystems;
import com.segmadesk.util.SegmaException;

public interface IAppSystemHome {



	List<AppSystems> getAllSystem()throws SegmaException;
	AppSystems getSelectedSystem(String appId) throws SegmaException;
}
