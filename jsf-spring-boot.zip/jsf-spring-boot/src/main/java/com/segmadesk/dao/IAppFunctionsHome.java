package com.segmadesk.dao;

import java.util.List;

import com.segmadesk.model.AppSysFunctions;
import com.segmadesk.util.SegmaException;

public interface IAppFunctionsHome {

	List<AppSysFunctions> getAllPages() throws SegmaException;

	AppSysFunctions findByPageId(String id, String appId) throws SegmaException;

}
