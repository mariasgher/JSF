package com.segmadesk.dao.impl;
// Generated Jun 16, 2016 12:43:07 PM by Hibernate Tools 5.1.0.Alpha1

import java.io.Serializable;
import java.sql.SQLIntegrityConstraintViolationException;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.segmadesk.dao.IAppRoleFunctionsHome;
import com.segmadesk.dao.ICustomer;
import com.segmadesk.model.Customer;
import com.segmadesk.util.SegmaException;



@Repository("iCustomer")
public class CustomerImpl extends AbstractDao implements Serializable, ICustomer { 
	/**
	 * 
	 */
	private static final long serialVersionUID = -8993464589052426856L;






	@Override
	public boolean saveBean(Customer customer) throws SegmaException, SQLIntegrityConstraintViolationException {
		try {

			getSession().save(customer);

			return true;
		} catch (Exception ex) {

			throw new SegmaException(ex);

		}
	}
	
	
}
