package com.segmadesk.dao.impl;

import java.io.Serializable;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import com.segmadesk.dao.IAppSystemHome;
import com.segmadesk.model.AppSystems;
import com.segmadesk.model.AppUsers;
import com.segmadesk.util.Constants;
import com.segmadesk.util.SegmaException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


@Repository("iAppSystemHome")
public class AppSystemHome  extends AbstractDao implements IAppSystemHome,Serializable {


	/**
	 * 
	 */
	private static final long serialVersionUID = -5740505231907477574L;
	private static final Log log = LogFactory.getLog(AppSystemHome.class);


	@Autowired
	EntityManager em;

	@Override
	public List<AppSystems> getAllSystem() throws SegmaException {



		CriteriaBuilder cb = em.getCriteriaBuilder();
		CriteriaQuery<AppSystems> cq = cb.createQuery(AppSystems.class);

		Root<AppSystems> user = cq.from(AppSystems.class);

		cq.select(user);

		TypedQuery<AppSystems> query = em.createQuery(cq);
		em.clear();
		em.close();

		return query.getResultList();

	}




	@Override
	public AppSystems getSelectedSystem(String appId) throws SegmaException {



		try {

			Criteria criteria = getSession().createCriteria(AppSystems.class);
			criteria.add( Restrictions.eq("appId", appId));
			criteria.add( Restrictions.eq("active", Constants.SegmaStatus.ActiveUser));
			return  (AppSystems) criteria.uniqueResult();


		} catch (Exception e) {
			throw new SegmaException(e);
		}

	}
}
