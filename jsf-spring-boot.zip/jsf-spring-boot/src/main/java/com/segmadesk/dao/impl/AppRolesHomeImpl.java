package com.segmadesk.dao.impl;
// Generated Jun 16, 2016 12:43:07 PM by Hibernate Tools 5.1.0.Alpha1

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import com.segmadesk.dao.IAppRolesHome;
import com.segmadesk.dto.UserRolePicklistDto;
import com.segmadesk.model.AppSysRoles;
import com.segmadesk.util.Constants;
import com.segmadesk.util.SegmaException;

import org.hibernate.Criteria;
import org.hibernate.Hibernate;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


@Repository("iAppRolesHome")
public class AppRolesHomeImpl extends AbstractDao implements IAppRolesHome, Serializable{

	private static final long serialVersionUID = -6480124091683491937L;
	/**
	 * 
	 */
	
	@Autowired
	 EntityManager em;
	
	@Override
	public List<AppSysRoles> getAllAppRoles() throws SegmaException {

		try {
			Criteria criteria = getSession().createCriteria(AppSysRoles.class);
			criteria.add(Restrictions.eq("active", Constants.SegmaStatus.ActiveUser));

			List<AppSysRoles> appRoles = criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
			for (AppSysRoles appRole : appRoles) {
				Hibernate.initialize(appRole.getAppSystems());
			}

			return appRoles;
		} catch (Exception e) {
			throw new SegmaException(e);
		}

	}

	@Override
	public List<AppSysRoles> getAllAppRolesAgainstApplication(String systemId) throws SegmaException {

		try {
			
			 CriteriaBuilder cb = em.getCriteriaBuilder();
		        CriteriaQuery<AppSysRoles> cq = cb.createQuery(AppSysRoles.class);

		        Root<AppSysRoles> sysRoles = cq.from(AppSysRoles.class);
		        Predicate activePredicate = cb.equal(sysRoles.get("active"), Constants.SegmaStatus.ActiveUser);
		        Predicate verifyStatusPredicate = cb.equal(sysRoles.get("verSts"), Constants.SegmaMakerCheckerStatus.Approve);
		        Predicate branchIdPredicate = cb.equal(sysRoles.get("id").get("appId"), systemId);
		        
		        cq.where(activePredicate, verifyStatusPredicate,branchIdPredicate);
		        cq.distinct(true);
		        TypedQuery<AppSysRoles> query = em.createQuery(cq);
		        em.clear();
		        em.close();
		        
		        List<AppSysRoles> appRoles =  query.getResultList();
		
			for (AppSysRoles appSysRoles : appRoles) {
				Hibernate.initialize(appSysRoles.getAppSystems());
			}

			return appRoles;
		} catch (Exception e) {
			throw new SegmaException(e);
		}

	}

	@Override
	public List<AppSysRoles> getAllRoles() throws SegmaException {

		try {

			Criteria criteria = getSession().createCriteria(AppSysRoles.class);

			List<AppSysRoles> appRoles = criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();

			return appRoles;
		} catch (Exception e) {
			throw new SegmaException(e);
		}

	}

	@Override
	public List<AppSysRoles> getRolesAgainstId(List<String> roleIds) throws SegmaException {

		try {

			Criteria criteria = getSession().createCriteria(AppSysRoles.class);
			criteria.add(Restrictions.eq("active", Constants.SegmaStatus.ActiveUser));
			if (roleIds.isEmpty()) {
				return new ArrayList<AppSysRoles>();
			}
			criteria.add(Restrictions.in("id.roleId", roleIds));
			List<AppSysRoles> appRoles = criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();

			return appRoles;
		} catch (Exception e) {
			throw new SegmaException(e);
		}

	}

	@Override
	public List<AppSysRoles> getRolesAgainstIds( List<String> roleIds) throws SegmaException {

		try {
		CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery<AppSysRoles> cq = cb.createQuery(AppSysRoles.class);

        Root<AppSysRoles> branch = cq.from(AppSysRoles.class);
        Predicate activePredicate = cb.equal(branch.get("active"), Constants.SegmaStatus.ActiveUser);
       
        cq.where(activePredicate);
        cq.distinct(true);
        TypedQuery<AppSysRoles> query = em.createQuery(cq);
        em.clear();
        em.close();
        
        return query.getResultList();
        
		
		} catch (Exception e) {
			throw new SegmaException(e);
		}

	}

	@Override
	public void blockRole(AppSysRoles roleBlockObj, String userId) throws SegmaException {

		try {

			Query query = getSession().createSQLQuery("UPDATE APP_ROLES" + " SET ACTIVE='"
					+ Constants.SegmaStatus.Block + "' , STATUS='" + Constants.SegmaMakerCheckerStatus.EditUser + "' "
					+ ", OLD_ACTIVE='" + roleBlockObj.getActive() + "' " + ", OLD_STATUS='"
					+ roleBlockObj.getOldVerSts() + "', INPUT_BY = '" + userId + "',INPUT_DATE = " + "SYSDATE"

					+ " where ROLE_ID ='" + roleBlockObj.getId().getRoleId() + "'");

			int a = query.executeUpdate();

		} catch (Exception e) {
			throw new SegmaException(e);
		}
	}

	@Override
	public int approve(AppSysRoles userApproveObj, String userId, String appId) throws SegmaException {

		try {

			Query query = getSession().createSQLQuery(
					"UPDATE APP_SYS_ROLES" + " SET ACTIVE='" + Constants.SegmaStatus.Block + "' , VER_STS='"
							+ Constants.SegmaMakerCheckerStatus.Approve + "' , VER_BY = '" + userId + "',VER_DATE  = "
							+ "SYSDATE" + ", REMARKS = '" + userApproveObj.getRemarks() + "' where ROLE_ID ='"
							+ userApproveObj.getId().getRoleId() + "' AND APP_ID='" + appId + "'");

			Query query1 = getSession().createSQLQuery("UPDATE APP_ROLE_FUNCTIONS" + " SET ACTIVE='"
					+ Constants.SegmaStatus.Block + "' , VER_BY = '" + userId + "',VER_DATE = " + "SYSDATE"

					+ " where ROLE_ID ='" + userApproveObj.getId().getRoleId() + "'");

			int a = query.executeUpdate();
			int b = query1.executeUpdate();

			return a;

		} catch (Exception e) {

			throw new SegmaException(e);
		}
	}

	@Override
	public void reject(AppSysRoles userApproveObj, String userId, String appId) throws SegmaException {

		try {

			Query query = getSession().createSQLQuery("UPDATE APP_SYS_ROLES" + " SET ACTIVE='"
					+ userApproveObj.getOldActive() + "' , VER_STS='" + userApproveObj.getOldVerSts() + "' , VER_BY = '"
					+ userId + "', REMARKS = '" + userApproveObj.getRemarks() + "',VER_DATE  = " + "SYSDATE"

					+ " where ROLE_ID ='" + userApproveObj.getId().getRoleId() + "' AND APP_ID='" + appId + "'");

			int a = query.executeUpdate();

		} catch (Exception e) {

			throw new SegmaException(e);
		}
	}

	@Override
	public List getSdmuRole(String userID, String roleId) throws SegmaException {

		try {

			Query query = getSession().createSQLQuery(
					"select * from APP_USER_ROLES where USER_ID='" + userID + "' AND ROLE_ID='" + roleId + "'");

			List sdmuLst = query.list();

			return sdmuLst;

		} catch (Exception e) {
			throw new SegmaException(e);
		}

	}

	@Override
	public List<UserRolePicklistDto> getAllAppRolesDtoAgainstApplication(String systemId) throws SegmaException {

		try {
			Criteria criteria = getSession().createCriteria(AppSysRoles.class);
			criteria.add(Restrictions.eq("id.appId", systemId));
			criteria.add(Restrictions.eq("active", Constants.SegmaActiveUser.ActiveUser));
			criteria.add(Restrictions.eq("verSts", Constants.SegmaMakerCheckerStatus.Approve));

			List<AppSysRoles> appRoles = criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
			List<UserRolePicklistDto> userRolesSource = new ArrayList<UserRolePicklistDto>();
			for (AppSysRoles appSysRoles : appRoles) {
				userRolesSource
						.add(new UserRolePicklistDto(appSysRoles.getId().getAppId(), appSysRoles.getId().getRoleId(),
								appSysRoles.getAppSystems().getAppName(), appSysRoles.getRoleName()));
			}
			return userRolesSource;
		} catch (Exception e) {
			throw new SegmaException(e);
		}

	}
}
