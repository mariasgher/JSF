package com.segmadesk.dao;

import java.sql.SQLIntegrityConstraintViolationException;
import java.util.Date;
import java.util.List;

import com.segmadesk.dto.StoreProcedureReturn;
import com.segmadesk.model.AppSysRoles;
import com.segmadesk.model.AppUserRoles;
import com.segmadesk.model.AppUsers;
import com.segmadesk.util.SegmaException;

public interface ICommonHome {

	boolean saveBean(Object bean) throws SegmaException, SQLIntegrityConstraintViolationException;

	boolean saveMultipleObject(Object bean, List<AppUserRoles> beanLst) throws SegmaException;

	int updateMultipleObject(Object bean, List<AppUserRoles> beanLst) throws SegmaException;

	int updateBean(Object bean) throws SegmaException;


	boolean updateRolesUserFunction(AppSysRoles roleid) throws SegmaException;

	boolean updateRolesUser(AppUsers userEditObj) throws SegmaException;

	boolean deleteBean(Object bean);

	int delete(String table, String whereField, Object whereValue);

	int saveOrUpdate(Object bean) throws SegmaException;

	void deletePages(List<String> selectedPages1, String roleId, List<String> pagesIdsForAssigned) throws SegmaException;


	Date getSystemDate() throws SegmaException;

	

	AppSysRoles getRolesAgainstApplication(String name)throws SegmaException;

	boolean savePages(String roleid, List<String> targetPages, StoreProcedureReturn manage, String appId) throws SegmaException;

	int updateUser(AppUsers bean) throws SegmaException;

	boolean updateMultipleUserObject(List<AppUsers> users, String verBy) throws SegmaException;

	boolean reactivateBranchUsers(List<AppUsers> users, String verBy) throws SegmaException;


}
