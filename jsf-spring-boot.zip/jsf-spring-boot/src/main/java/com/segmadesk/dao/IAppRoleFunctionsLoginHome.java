package com.segmadesk.dao;

import java.util.List;

import com.segmadesk.model.AppRoleFunctions;
import com.segmadesk.util.SegmaException;

public interface IAppRoleFunctionsLoginHome {

	List getAlreadyAddedPages(String roleId) throws SegmaException;

	List getAllRolePages() throws SegmaException;

	int blockRoleFunction(AppRoleFunctions pojotToUpperCase, String userid) throws SegmaException;

	List getPickListPages(String roleId, String appId) throws SegmaException;
	
	List getAllPages(String roleId, String appId) throws SegmaException ;

	AppRoleFunctions findByPageId(String pageId, String roleId, String appId) throws SegmaException;

}
