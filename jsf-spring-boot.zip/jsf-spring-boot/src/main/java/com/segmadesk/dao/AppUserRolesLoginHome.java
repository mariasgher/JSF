package com.segmadesk.dao;

import java.util.List;

import com.segmadesk.dto.StoreProcedureReturn;
import com.segmadesk.dto.UserRolePicklistDto;
import com.segmadesk.model.AppUserRoles;
import com.segmadesk.model.AppUserRolesId;
import com.segmadesk.util.SegmaException;

import org.primefaces.model.DualListModel;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AppUserRolesLoginHome extends CrudRepository<AppUserRoles, AppUserRolesId> {

	List<String> getRoleAgainstUserId(String userID) throws SegmaException;

	List<AppUserRoles> getAppUserRolesAgainstApplication(String systemId, String userId) throws SegmaException;

	List<UserRolePicklistDto> getAppUserRolesDtoAgainstApplication(String systemId, String userId)throws SegmaException;



	int saveUserRole(String roleid, DualListModel<String> targetRoles, StoreProcedureReturn manage, String appId,
			String userId) throws SegmaException;


	List<AppUserRoles> getAllInActiveUserRole(String userId) throws SegmaException;

	int rejectRole(String roleId, String appId, String userId) throws SegmaException;

}
