package com.segmadesk.dao;

import java.util.List;

import com.segmadesk.model.AppSysModules;
import com.segmadesk.util.SegmaException;

public interface IAppModulesHome {
	
	public List<AppSysModules> getAllModules() throws SegmaException ;
	

}
