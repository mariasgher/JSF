package com.segmadesk.dao;

import java.sql.SQLException;
import java.util.List;

import com.segmadesk.dto.StoreProcedureReturn;
import com.segmadesk.dto.UserRolesApplications;
import com.segmadesk.model.AppUsers;
import com.segmadesk.util.SegmaException;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface AppUsersLoginHome extends CrudRepository<AppUsers, String>   {

	StoreProcedureReturn firstTimeLogin(String userName, String password) throws SegmaException, SQLException;

	AppUsers getAppUsers(String userName) throws SegmaException;

	String encryptPassword(String password) throws SegmaException;


	StoreProcedureReturn ChangePassword(String username, String password, String oldPassword) throws SQLException, SegmaException;


	StoreProcedureReturn SendEmail(String userId, String callFlag) throws SQLException, SegmaException;


	boolean isUsernameExist(String username) throws SegmaException;



	int blockUser(AppUsers userEditObj, String userId) throws SegmaException;

	List<AppUsers> pendingUsers(String userId) throws SegmaException;

	List<AppUsers> getUsersNotCreatedBy(String userid) throws SegmaException;


	List<UserRolesApplications> getApplicationName(String username)throws SegmaException;

	List<String> getRoles(String username, int i) throws SegmaException;

	List<AppUsers> allUsers() throws SegmaException;

	List<AppUsers> rejUsers(String userId) throws SegmaException;

}
