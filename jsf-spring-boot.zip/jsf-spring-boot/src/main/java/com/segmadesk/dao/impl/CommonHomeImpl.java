package com.segmadesk.dao.impl;

import java.io.Serializable;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.sql.DataSource;

import com.segmadesk.dao.IAppFunctionsHome;
import com.segmadesk.dao.IAppRoleFunctionsHome;
import com.segmadesk.dao.ICommonHome;
import com.segmadesk.dto.StoreProcedureReturn;
import com.segmadesk.model.AppRoleFunctions;
import com.segmadesk.model.AppSysFunctions;
import com.segmadesk.model.AppSysRoles;
import com.segmadesk.model.AppUserRoles;
import com.segmadesk.model.AppUsers;
import com.segmadesk.util.Constants;
import com.segmadesk.util.SegmaException;
import com.segmadesk.util.ToUpperCase;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository("iCommonHome")
public class CommonHomeImpl extends AbstractDao implements ICommonHome, Serializable {

	/**
	 * 
	 */
	private static final Logger LOGGER = LogManager.getLogger(CommonHomeImpl.class);
	private static final long serialVersionUID = -3413826220153047732L;
	@Autowired
	private IAppFunctionsHome appPages;

	@Autowired
	private IAppRoleFunctionsHome appRolePages;

	@Autowired
	EntityManager em;

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private DataSource dataSource;

	@Override
	public boolean saveBean(Object bean) throws SegmaException, SQLIntegrityConstraintViolationException {
		try {

			getSession().save(bean);

			return true;
		} catch (Exception ex) {

			throw new SegmaException(ex);

		}
	}

	@Override
	public boolean saveMultipleObject(Object bean, List<AppUserRoles> beanLst) throws SegmaException {
		try {

			em.persist(bean);
			for (Iterator iterator = beanLst.iterator(); iterator.hasNext();) {
				AppUserRoles appUserRoles = (AppUserRoles) iterator.next();
				em.persist(appUserRoles);
			}

			em.clear();
			em.close();
			return true;
		} catch (Exception ex) {

			throw new SegmaException(ex);

		}
	}

	@Override
	public synchronized int updateMultipleObject(Object bean, List<AppUserRoles> beanLst) throws SegmaException {
		try {

			getSession().saveOrUpdate(bean);
			deleteAllRolesAgainstUser(bean);
			for (Iterator iterator = beanLst.iterator(); iterator.hasNext();) {
				AppUserRoles appUserRoles = (AppUserRoles) iterator.next();

				getSession().saveOrUpdate(appUserRoles);
			}

			return 1;
		} catch (Exception ex) {

			throw new SegmaException(ex);

		}
	}

	@Override
	public synchronized int updateBean(Object bean) throws SegmaException {
		try {

			getSession().update(bean);

			return 1;
		} catch (Exception ex) {
			throw new SegmaException(ex);

		}
	}

	@Override
	public synchronized int updateUser(AppUsers bean) throws SegmaException {
		try {

			String sql = "UPDATE  APP_USERS SET " +
					" CNIC			=	'"+ bean.getCnic() + "', " +
					" CONTACT_NO	=	'"+ bean.getContactNo() + "', " +
					" EMAIL			=	'"+ bean.getEmail() + "', " +
					" USERNAME		=	'"+ bean.getUsername() + "', " +					
					" REMARKS		=	'"+ bean.getRemarks() + "', " +
					" INPUT_BY 		=  	'"+bean.getInputBy()+"',"+
					" INPUT_DATE 	= 	SYSDATE, "+
					" ACTIVE 		= 	'"+bean.getActive()+"', "+
					" VER_STS 		=	'"+bean.getVerSts()+"' " +					
					" WHERE  USERID ='" + bean.getUserid() + "'";
			int result = jdbcTemplate.update(sql);
			return result;
		} catch (Exception ex) {
			throw new SegmaException(ex);

		}
	}

	public synchronized int update(String table, String whereField, Object whereValue, String updateField,
			Object value) {
		try {

			String hqlDelete = "update com.segmadesk.model." + table + " set " + updateField + "=:val1 where "
					+ whereField + "= :val2";
			Query query = getSession().createQuery(hqlDelete);

			if (value instanceof Long)
				query.setLong("val1", ((Long) value).longValue());
			else if (value instanceof String)
				query.setString("val1", (String) value);
			else if (value instanceof Byte)
				query.setByte("val1", (Byte) value);
			else if (value instanceof Integer)
				query.setInteger("val1", (Integer) value);
			else if (value instanceof Boolean)
				query.setBoolean("val1", (Boolean) value);
			else if (value instanceof Date)
				query.setDate("val1", (Date) value);
			else
				query.setEntity("val1", value);

			if (whereValue instanceof Long)
				query.setLong("val2", ((Long) whereValue).longValue());
			else if (whereValue instanceof String)
				query.setString("val2", (String) whereValue);
			else if (whereValue instanceof Boolean)
				query.setBoolean("val2", (Boolean) whereValue);
			else
				query.setEntity("val2", whereValue);

			int updateEntities = query.executeUpdate();

			return updateEntities;
		} catch (Exception ex) {

			ex.printStackTrace();
			return -1;

		}
	}

	public synchronized int update(String table, String whereFields[], Object whereValues[], String updateField,
			Object value) {
		try {
			if (whereFields.length != whereValues.length)
				return -1;

			StringBuilder hqlDelete = new StringBuilder("update com.segmadesk.model.");
			hqlDelete.append(table + " set " + updateField + "=:val");
			StringBuilder strWhere = new StringBuilder();
			for (int i = 0; i < whereFields.length; i++) {
				strWhere.append(" where " + whereFields[i] + "= :val" + i + ",");
			}
			Query query = getSession().createQuery(hqlDelete.toString());

			if (value instanceof Long)
				query.setLong("val", ((Long) value).longValue());
			else if (value instanceof String)
				query.setString("val", (String) value);
			else if (value instanceof Byte)
				query.setByte("val", (Byte) value);
			else if (value instanceof Integer)
				query.setInteger("val", (Integer) value);
			else if (value instanceof Boolean)
				query.setBoolean("val", (Boolean) value);
			else if (value instanceof Date)
				query.setDate("val", (Date) value);
			else
				query.setEntity("val", value);

			for (int i = 0; i < whereValues.length; i++) {
				if (whereValues[i] instanceof Long)
					query.setLong("val" + i, ((Long) whereValues[i]).longValue());
				else if (whereValues[i] instanceof String)
					query.setString("val" + i, (String) whereValues[i]);
				else if (whereValues[i] instanceof Boolean)
					query.setBoolean("val" + i, (Boolean) whereValues[i]);
			}

			int updateEntities = query.executeUpdate();

			return updateEntities;
		} catch (Exception ex) {

			return -1;

		}
	}

	public synchronized int update(String table, String whereField, Object whereValue, String updateFields[],
			Object updateValues[]) {
		try {
			if (updateFields.length != updateValues.length)
				return -1;

			StringBuilder strUpdate = new StringBuilder("set ");

			for (int i = 0; i < updateFields.length - 1; i++) {
				strUpdate.append(updateFields[i] + "=:val" + i + ", ");
			}
			strUpdate.append(updateFields[updateFields.length - 1] + "=:val" + (updateFields.length - 1) + "");

			StringBuilder hqlDelete = new StringBuilder(
					"update com.segmadesk.model." + table + " " + strUpdate + " where " + whereField + "=:val");
			Query query = getSession().createQuery(hqlDelete.toString());

			if (whereValue instanceof Long)
				query.setLong("val", ((Long) whereValue).longValue());
			else if (whereValue instanceof String)
				query.setString("val", (String) whereValue);
			else if (whereValue instanceof Byte)
				query.setByte("val", (Byte) whereValue);
			else if (whereValue instanceof Integer)
				query.setInteger("val", (Integer) whereValue);
			else if (whereValue instanceof Boolean)
				query.setBoolean("val", (Boolean) whereValue);
			else
				query.setEntity("val", whereValue);

			for (int i = 0; i < updateValues.length; i++) {
				if (updateValues[i] instanceof Long)
					query.setLong("val" + i, ((Long) updateValues[i]).longValue());
				else if (updateValues[i] instanceof String)
					query.setString("val" + i, (String) updateValues[i]);
				else if (updateValues[i] instanceof Byte)
					query.setByte("val" + i, (Byte) updateValues[i]);
				else if (updateValues[i] instanceof Integer)
					query.setInteger("val" + i, (Integer) updateValues[i]);
				else if (updateValues[i] instanceof Boolean)
					query.setBoolean("val" + i, (Boolean) updateValues[i]);
				else
					query.setEntity("val" + i, updateValues[i]);
			}

			int updateEntities = query.executeUpdate();

			return updateEntities;
		} catch (Exception ex) {
			ex.printStackTrace();

			return -1;

		}
	}

	@Override
	public boolean deleteBean(Object bean) {

		try {

			getSession().delete(bean);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;

		}
	}

	
	public int deleteAllRolesAgainstUser(Object userObj) throws SegmaException {

		AppUsers appUser = (AppUsers) userObj;

		try {
			Query query = getSession()
					.createSQLQuery("DELETE  FROM APP_USER_ROLES WHERE USER_ID='" + appUser.getUserid() + "'");

			return query.executeUpdate();
		} catch (Exception e) {
			throw new SegmaException(e);
		}

	}

	@Override
	public Date getSystemDate() throws SegmaException {

		try {

			Query query = getSession().createSQLQuery("SELECT SYSDATE FROM DUAL");

			return (Date) query.uniqueResult();
		} catch (Exception e) {
			throw new SegmaException(e);
		}

	}

	@Override
	public synchronized int delete(String table, String whereField, Object whereValue) {
		try {

			String hqlDelete = "delete from com.segmadesk.model." + table + " where " + whereField + "= :val";

			Query query = getSession().createQuery(hqlDelete);

			if (whereValue instanceof Long)
				query.setLong("val", ((Long) whereValue).longValue());
			else if (whereValue instanceof String)
				query.setString("val", (String) whereValue);

			int deleteEntities = query.executeUpdate();

			return deleteEntities;
		} catch (Exception ex) {
			ex.printStackTrace();
			return -1;
		}
	}

	@Override
	public synchronized int saveOrUpdate(Object bean) throws SegmaException {
		try {

			getSession().saveOrUpdate(bean);

			return 1;
		} catch (Exception ex) {
			throw new SegmaException(ex);

		}

	}

	@Override
	public boolean savePages(String roleid, List<String> targetPages, StoreProcedureReturn manage, String appId)
			throws SegmaException {

		try {

			List<String> previousPagesIds = findAllPagesbyRole(roleid, appId); // previous page ids

			// preparing deleted list
			ArrayList<String> deleteLst = new ArrayList<String>(previousPagesIds);
			deleteLst.removeAll(targetPages);
			LOGGER.debug("delete Record: " + deleteLst);

			// preparing added list
			ArrayList<String> newLst = new ArrayList<String>(targetPages);
			newLst.removeAll(previousPagesIds);
			LOGGER.debug("add  record: " + newLst);

			// prepare new string from list having concatenated roles

			for (String newObjDelete : newLst) {
				Query queryDeleteNewLst = getSession()
						.createSQLQuery("DELETE APP_ROLE_FUNCTIONS " + " WHERE ROLE_ID = '" + roleid
								+ "' AND USER_ID ='" + newObjDelete + "' AND APP_ID ='" + appId + "'");

				queryDeleteNewLst.executeUpdate();
			}

			for (String newObj : newLst) {

				AppSysFunctions functionObj = appPages.findByPageId(newObj, appId);
				StringBuilder strInsert = new StringBuilder();
				strInsert.append(
						"INSERT INTO APP_ROLE_FUNCTIONS (VER_STS , ACTIVE, INPUT_BY, INPUT_DATE, ROLE_ID,APP_ID,MODULE_ID, DESCRIPTION,PAGE_ID)");
				strInsert.append("VALUES ('" + Constants.SegmaMakerCheckerStatus.NewUser + "' ,");
				strInsert.append("  '" + Constants.SegmaStatus.InActive + "',");
				strInsert.append("   '" + manage.getUserName() + "',");
				strInsert.append("   sysdate ,");
				strInsert.append("  '" + roleid + "'");
				strInsert.append("  '" + appId + "'");
				strInsert.append("  '" + functionObj.getAppSysModules().getId().getModuleId() + "'");
				strInsert.append(" , '" + functionObj.getFriendlyName() + "'");
				strInsert.append(" , '" + newObj + "')");

				Query queryNewLst = getSession().createSQLQuery(strInsert.toString());

				queryNewLst.executeUpdate();
			}

			for (String deleteObj : deleteLst) {
				StringBuilder strPageUpdate = new StringBuilder();
				AppRoleFunctions functionObj = appRolePages.findByPageId(deleteObj, roleid, appId);

				strPageUpdate.append("UPDATE APP_ROLE_FUNCTIONS SET ");
				strPageUpdate.append(" OLD_STATUS='" + functionObj.getVerSts() + "' ,");
				strPageUpdate.append(" OLD_ACTIVE ='" + functionObj.getActive() + "' ,");
				strPageUpdate.append(" VER_STS='" + Constants.SegmaMakerCheckerStatus.EditUser + "' ,");
				strPageUpdate.append(" ACTIVE ='" + Constants.SegmaStatus.InActive + "' ,");
				strPageUpdate.append(" INPUT_BY = '" + manage.getUserName() + "',");
				strPageUpdate.append(" INPUT_DATE = sysdate");
				strPageUpdate.append(" WHERE ROLE_ID = '" + roleid + "' AND PAGE_ID ='" + deleteObj + "' AND APP_ID ='"
						+ appId + "'");

				Query queryOldLst = getSession().createSQLQuery(strPageUpdate.toString());

				queryOldLst.executeUpdate();
			}

			return true;
		} catch (Exception ex) {
			throw new SegmaException(ex);

		}

	}

	@Override
	public boolean updateRolesUserFunction(AppSysRoles roleid) throws SegmaException {

		try {

			Query updateRoleQuery = getSession().createSQLQuery(
					"UPDATE APP_SYS_ROLES" + " SET ROLE_TYPE = '" + roleid.getRoleType() + "' ,INPUT_BY = '"
							+ roleid.getInputBy() + "'  ,ACTIVE = '" + Constants.SegmaStatus.InActive
							+ "', VER_STS = '" + Constants.SegmaMakerCheckerStatus.EditUser + "'" + " WHERE ROLE_ID='"
							+ roleid.getId().getRoleId() + "' AND APP_ID='" + roleid.getId().getAppId() + "'");

			Query updateRoleFunctionQuery = getSession()
					.createSQLQuery("UPDATE APP_ROLE_FUNCTIONS" + " SET ACTIVE = '" + Constants.SegmaStatus.InActive
							+ "', VER_STS = '" + Constants.SegmaMakerCheckerStatus.EditUser + "'" + " WHERE ROLE_ID='"
							+ roleid.getId().getRoleId() + "' AND APP_ID='" + roleid.getId().getAppId() + "'");

			Query updateRoleUserQuery = getSession()
					.createSQLQuery("UPDATE APP_USER_ROLES" + " SET ACTIVE = '" + Constants.SegmaStatus.InActive
							+ "', VER_STS = '" + Constants.SegmaMakerCheckerStatus.EditUser + "'" + " WHERE ROLE_ID='"
							+ roleid.getId().getRoleId() + "' AND APP_ID='" + roleid.getId().getAppId() + "'");

			updateRoleQuery.executeUpdate();
			updateRoleFunctionQuery.executeUpdate();
			updateRoleUserQuery.executeUpdate();

			return true;
		} catch (Exception ex) {
			throw new SegmaException(ex);

		}
	}

	@Override
	public boolean updateRolesUser(AppUsers userEditObj) throws SegmaException {

		try {

			// getSession().update(userEditObj);

			String qry = "";

			qry += " UPDATE APP_USERS ";
			qry += " SET VER_BY         = '" + userEditObj.getVerBy() + "',";
			qry += "     VER_DATE       = SYSDATE ,";
			qry += " 	 ACTIVE         = '" + userEditObj.getActive() + "',";
			qry += "     VER_STS        = '" + userEditObj.getVerSts() + "', ";
			qry += "     REMARKS        = '" + userEditObj.getRemarks() + "' ";
			qry += " WHERE USERID       = '" + userEditObj.getUserid() + "' ";

			jdbcTemplate.update(qry);

			Iterator itr = userEditObj.getAppUserRoleses().iterator();
			while (itr.hasNext()) {
				String updateRoleUserQuery = "";
				AppUserRoles appUserRoles = (AppUserRoles) itr.next();

				if (userEditObj.getActive().equalsIgnoreCase(Constants.SegmaStatus.ActiveUser)) {
					updateRoleUserQuery = "UPDATE APP_USER_ROLES" + " SET ACTIVE = '"
							+ Constants.SegmaStatus.ActiveUser + "', VER_STS = '"
							+ Constants.SegmaMakerCheckerStatus.Approve + "' , VER_BY = '" + userEditObj.getVerBy()
							+ "',VER_DATE = sysdate" + " WHERE USER_ID='" + appUserRoles.getId().getUserId()
							+ "' AND APP_ID='" + appUserRoles.getId().getAppId() + "' AND ROLE_ID='"
							+ appUserRoles.getId().getRoleId() + "'";

				} else if (userEditObj.getActive().equalsIgnoreCase(Constants.SegmaStatus.InActive)) {
					updateRoleUserQuery = "UPDATE APP_USER_ROLES" + " SET ACTIVE = '" + Constants.SegmaStatus.InActive
							+ "', VER_STS = '" + Constants.SegmaMakerCheckerStatus.EditUser + "' , VER_BY = '"
							+ userEditObj.getVerBy() + "',VER_DATE = sysdate" + " WHERE USER_ID='"
							+ appUserRoles.getId().getUserId() + "' AND APP_ID='" + appUserRoles.getId().getAppId()
							+ "' AND ROLE_ID='" + appUserRoles.getId().getRoleId() + "'";

				}
				if (userEditObj.getActive().equalsIgnoreCase(Constants.SegmaStatus.Block)) {
					updateRoleUserQuery = "UPDATE APP_USER_ROLES" + " SET ACTIVE = '" + Constants.SegmaStatus.Block
							+ "', VER_STS = '" + Constants.SegmaMakerCheckerStatus.Approve + "' , VER_BY = '"
							+ userEditObj.getVerBy() + "',VER_DATE = sysdate" + " WHERE USER_ID='"
							+ appUserRoles.getId().getUserId() + "' AND APP_ID='" + appUserRoles.getId().getAppId()
							+ "' AND ROLE_ID='" + appUserRoles.getId().getRoleId() + "'";
				}

				jdbcTemplate.update(updateRoleUserQuery);

			}

			return true;
		} catch (Exception ex) {
			throw new SegmaException(ex);

		}
	}

	public List<String> findAllPagesbyRole(String roleId, String appId) throws SegmaException {

		try {

			Query query = getSession()
					.createSQLQuery("SELECT PAGE_ID FROM APP_ROLE_FUNCTIONS " + "where  ROLE_ID ='" + roleId
							+ "' AND APP_ID = '" + appId + "' AND  ( ACTIVE = '" + Constants.SegmaActiveUser.ActiveUser
							+ "' OR ( VER_STS = '" + Constants.SegmaMakerCheckerStatus.NewUser + "' AND ACTIVE ='"
							+ Constants.SegmaActiveUser.InActive + "'))");

			return query.list();

		} catch (Exception e) {
			throw new SegmaException(e);
		}
	}

	@Override
	public void deletePages(List<String> selectedPages1, String roleId, List<String> pagesIdsForAssigned)
			throws SegmaException {
		// list of pages ids to be deleted
		ArrayList<String> pagesIdToDelete = new ArrayList<String>();

		boolean flag = true;

		try {

			// getting the page_ids of pages that are in DB, but not selected
			// from UI
			for (String rolePagesInDB : pagesIdsForAssigned) {
				flag = true;
				for (String pageIdsSelected : selectedPages1) {
					if (pageIdsSelected.equals(rolePagesInDB)) {
						flag = false;
					}
				}
				if (flag) {
					pagesIdToDelete.add(rolePagesInDB);
				}

			}
			if (!pagesIdToDelete.isEmpty()) {
				for (String pageId : pagesIdToDelete) {
					Query query = getSession()
							.createSQLQuery("UPDATE  APP_ROLE_FUNCTIONS SET ACTIVE='" + Constants.SegmaStatus.InActive
									+ "' , STATUS='" + Constants.SegmaMakerCheckerStatus.NewUser
									+ "'  where  ROLE_ID ='" + roleId + "' and PAGE_ID = '" + pageId + "'");

					int result = query.executeUpdate();
				}
			}

		} catch (Exception e) {
			throw new SegmaException(e);
		}
	}

	@Override
	public boolean updateMultipleUserObject(List<AppUsers> users, String verBy)
			throws SegmaException {
		try {

			String allUsersToBeUpdated = new String();

			if (users != null) {
				String allUsersToBeUnactived = "";
				for (int i = 0; i < users.size(); i++) {
					allUsersToBeUnactived += "'" + users.get(i).getUserid() + "',";

				}
				allUsersToBeUnactived = allUsersToBeUnactived.substring(0, allUsersToBeUnactived.length() - 1);

				Query queryAppUser = getSession().createSQLQuery("UPDATE APP_USERS SET ACTIVE='"
						+ Constants.SegmaStatus.InActive + "' ,  REMARKS='" + "ok" + "' ,  VER_STS='"
						+ Constants.SegmaMakerCheckerStatus.NewUser + "' , VER_DATE=" + "SYSDATE" + " , VER_BY='"
						+ verBy + "'  WHERE USERID IN (" + allUsersToBeUnactived + ")");
				queryAppUser.executeUpdate();

				Query queryAppUserRoles = getSession().createSQLQuery(
						"UPDATE APP_USER_ROLES SET ACTIVE='" + Constants.SegmaStatus.InActive + "' , VER_DATE="
								+ "SYSDATE" + " ,  STATUS='" + Constants.SegmaMakerCheckerStatus.NewUser
								+ "' , VERIFY_BY='" + verBy + "'  WHERE USER_ID IN (" + allUsersToBeUnactived + ")");
				queryAppUserRoles.executeUpdate();

			}

			return true;

		} catch (Exception ex) {

			throw new SegmaException(ex);
		}

	}

	@Override
	public boolean reactivateBranchUsers(List<AppUsers> users, String verBy) throws SegmaException {
		try {
			if (users != null && !users.isEmpty() && users.size() > 0) {
				String allUsersToBeUnactived = "";
				for (int i = 0; i < users.size(); i++) {
					if (i == 0) {
						allUsersToBeUnactived += "'" + users.get(i).getUserid() + "'";
					} else {
						allUsersToBeUnactived += ",'" + users.get(i).getUserid() + "'";
					}
				}

				Query queryAppUser = getSession().createSQLQuery("UPDATE APP_USERS SET ACTIVE='"
						+ Constants.SegmaStatus.ActiveUser + "' ,  REMARKS='" + "ok"
						+ "' ,  VER_STS='" + Constants.SegmaMakerCheckerStatus.Approve + "' , VER_DATE=" + "SYSDATE"
						+ " , VER_BY='" + verBy + "'  WHERE USERID IN (" + allUsersToBeUnactived + ")");
				queryAppUser.executeUpdate();

				Query queryAppUserRoles = getSession().createSQLQuery(
						"UPDATE APP_USER_ROLES SET ACTIVE='" + Constants.SegmaStatus.ActiveUser + "' , VERIFY_DATE="
								+ "SYSDATE" + " ,  STATUS='" + Constants.SegmaMakerCheckerStatus.Approve
								+ "' , VERIFY_BY='" + verBy + "'  WHERE USER_ID IN (" + allUsersToBeUnactived + ")");
				queryAppUserRoles.executeUpdate();

			}
			return true;

		} catch (Exception ex) {

			throw new SegmaException(ex);
		}

	}

	public static void main(String[] args) {
		/*
		 * List<String> targetPages =
		 * Arrays.asList("12.xhtml","16.xhtml","17.xhtml","19.xhtml","101.xhtml");
		 * List<String> previousPagesIds =
		 * Arrays.asList("16.xhtml","19.xhtml","107.xhtml","108.xhtml","109.xhtml");
		 * 
		 * List<String> targetPages = Arrays.asList("12.xhtml","16.xhtml","19.xhtml");
		 * List<String> previousPagesIds =
		 * Arrays.asList("16.xhtml","19.xhtml","107.xhtml","108.xhtml","109.xhtml");
		 * 
		 * 
		 * // List<String> previousPagesIds = findAllPagesbyRole(roleid, session);
		 * //previous page ids
		 * 
		 * ArrayList<String> deleteLst = new ArrayList<String>(previousPagesIds);
		 * deleteLst.removeAll(targetPages); System.out.println("delete Record: " +
		 * deleteLst);
		 * 
		 * ArrayList<String> newLst = new ArrayList<String>(targetPages);
		 * newLst.removeAll(previousPagesIds); System.out.println("add  record: " +
		 * newLst); String result = StringUtils.join(newLst.iterator(), ",123"); String
		 * replaceString = new String(); if(newLst.size()>1){
		 * 
		 * replaceString = result.substring(result.lastIndexOf(','), result.length());
		 * result = "123"+result.substring(0,result.lastIndexOf(','))+(replaceString);
		 * 
		 * }else{
		 * 
		 * 
		 * result = ("123")+result.substring(0,result.length());
		 * 
		 * }
		 * 
		 * System.out.println(result);
		 * 
		 * 
		 */}

	@Override
	public AppSysRoles getRolesAgainstApplication(String name) throws SegmaException {

		try {
			Criteria criteria = getSession().createCriteria(AppSysRoles.class);
			String[] test = name.split("-");
			criteria.add(Restrictions.eq("id.appId", test[0]));
			criteria.add(Restrictions.eq("id.roleId", test[1]));

			return (AppSysRoles) criteria.uniqueResult();
		} catch (Exception e) {
			throw new SegmaException(e);
		}

	}

}