package com.segmadesk.dao;

import java.sql.SQLIntegrityConstraintViolationException;

import com.segmadesk.model.Customer;
import com.segmadesk.util.SegmaException;

public interface ICustomer {
	
	
	boolean saveBean(Customer customer) throws SegmaException, SQLIntegrityConstraintViolationException;

}
