package com.segmadesk.dao.impl;



import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;

import com.segmadesk.util.SegmaException;
public class AbstractDao {

	@Autowired
	private SessionFactory sessionFactory;

	 @Autowired
	    ApplicationContext applicationContext;
	 
	protected Session getSession(){
		
		return sessionFactory.openSession();
		
	}

	public void persist(Object entity) {
		getSession().persist(entity);
	}

	public void delete(Object entity) {
		getSession().delete(entity);
	}


}
