package com.segmadesk.dao.impl;
// Generated Jun 16, 2016 12:43:07 PM by Hibernate Tools 5.1.0.Alpha1

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import com.segmadesk.dao.AppUserRolesLoginHome;
import com.segmadesk.dao.IAppRolesHome;
import com.segmadesk.dto.StoreProcedureReturn;
import com.segmadesk.dto.UserRolePicklistDto;
import com.segmadesk.dto.oneColumnsMapper;
import com.segmadesk.model.AppSysRoles;
import com.segmadesk.model.AppUserRoles;
import com.segmadesk.model.AppUserRolesId;
import com.segmadesk.util.Constants;
import com.segmadesk.util.SegmaException;
import com.segmadesk.util.Constants.StaticStatus;

import org.hibernate.Criteria;
import org.hibernate.Hibernate;
import javax.persistence.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.hibernate.query.NativeQuery;
import org.primefaces.model.DualListModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;


@Repository
public class AppUserRolesLoginHomeImpl extends AbstractDao implements  Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 4298976796886504528L;

	@Autowired
	JdbcTemplate jdbcTemplate;

	@Autowired
	IAppRolesHome objImp ;

	@Autowired
	EntityManager em;



	public List<String> getRoleAgainstUserId(String userID) throws SegmaException {

		try {

			String sql = "SELECT USERROLES.ROLE_ID " + " FROM app_users appUser, APP_USER_ROLES userRoles "
					+ " WHERE userid='" + userID + "' " + " AND USERROLES.USER_ID = APPUSER.USERID "
					+ " AND (USERROLES.ROLE_ID = '" + StaticStatus.Static_Inputter + "' OR USERROLES.ROLE_ID = '"
					+ StaticStatus.Static_Approver + "') ";

			return jdbcTemplate.query(sql, new oneColumnsMapper());

		} catch (Exception e) {
			throw new SegmaException(e);
		}
	}


	public int saveUserRole(String roleid, DualListModel<String> targetRoles, StoreProcedureReturn manage, String appId,
			String userId) throws SegmaException {

		try {

			Session session = getSession();
			List<AppUserRoles> previousPagesIds = getAllPrevRolesByUserId(roleid, appId, userId); // previous page ids
			List<String> newAdd = new ArrayList<>();

		
			List<AppSysRoles> role = objImp.getRolesAgainstIds(targetRoles.getTarget());

			for (String newObjDelete : targetRoles.getSource()) {
				Query  queryDeleteNewLst = em.createNativeQuery("DELETE APP_USER_ROLES " + " WHERE ROLE_ID = '"
						+ newObjDelete + "' AND USERID ='" + userId + "' AND APP_ID ='" + appId + "'");

				queryDeleteNewLst.executeUpdate();
			}

			for (AppSysRoles appSysRoles : role) {

				StringBuilder strInsert = new StringBuilder();
				strInsert.append(
						"INSERT INTO APP_USER_ROLES (VER_STS,USER_ID,APP_ID,ROLE_ID,REMARKS,ACTIVE , INPUT_BY, INPUT_DATE ,VER_BY,VER_DATE)");
				strInsert.append("VALUES ('" + Constants.SegmaMakerCheckerStatus.NewUser + "' ,");
				strInsert.append("  '" + userId + "' ,");
				strInsert.append("  '" + appSysRoles.getId().getAppId() + "' ,");
				strInsert.append("  '" + appSysRoles.getId().getRoleId() + "' ,");
				strInsert.append("  '" + "USER ROLE ADDED" + "' ,");
				strInsert.append("  '" + Constants.SegmaStatus.InActive + "',");
				strInsert.append("   '" + manage.getUserName() + "',");
				strInsert.append("   sysdate() ,");
				strInsert.append(null + " ,");

				strInsert.append(null + ")");

				Query queryNewLst = em.createNativeQuery(strInsert.toString());

				queryNewLst.executeUpdate();
			}

			return 1;

		} catch (Exception ex) {
			throw new SegmaException(ex);

		}

	}

	public List<AppUserRoles> getAllPrevRolesByUserId(String roleId, String appId, String userId) throws SegmaException {

		try {
			CriteriaBuilder cb = em.getCriteriaBuilder();
			CriteriaQuery<AppUserRoles> cq = cb.createQuery(AppUserRoles.class);

			Root<AppUserRoles> branch = cq.from(AppUserRoles.class);
			Predicate activePredicate = cb.equal(branch.get("active"), Constants.SegmaStatus.ActiveUser);
			Predicate statusPredicate = cb.equal(branch.get("verSts"), Constants.SegmaMakerCheckerStatus.Approve);
			Predicate branchIdPredicate = cb.equal(branch.get("id").get("appId"), appId);
			Predicate userIdPredicate = cb.equal(branch.get("id").get("userId"), userId);

			cq.where(activePredicate, statusPredicate,branchIdPredicate,userIdPredicate);
			cq.distinct(true);
			TypedQuery<AppUserRoles> query = em.createQuery(cq);
			em.clear();
			em.close();

			List<AppUserRoles> appRoles =  query.getResultList();




			List<AppUserRoles> appRolesReturn = new ArrayList<AppUserRoles>();

			for (AppUserRoles appUserRolesObj : appRoles) {
				appRolesReturn.add(new AppUserRoles(
						new AppUserRolesId(appUserRolesObj.getId().getUserId(), appUserRolesObj.getId().getAppId(),
								appUserRolesObj.getId().getRoleId()),
						appUserRolesObj.getAppUsers(), appUserRolesObj.getAppSysRoles(), appUserRolesObj.getRemarks(),
						appUserRolesObj.getActive(), appUserRolesObj.getInputBy(), appUserRolesObj.getInputDate(),
						appUserRolesObj.getVerBy(), appUserRolesObj.getVerDate(), appUserRolesObj.getVerSts()));
			}
			for (AppUserRoles role : appRoles) {
				Hibernate.initialize(role.getAppSysRoles());

			}
			return appRoles;
		} catch (Exception e) {
			throw new SegmaException(e);
		}

	}

	public List<AppUserRoles> findAllPagesbyRole(String roleId, String appId, String userId) throws SegmaException {

		try {

			Query query = getSession().createNativeQuery(
					"SELECT * FROM APP_USER_ROLES " + "where  USER_ID ='" + userId + "' AND APP_ID = '" + appId + "'");

			return  query.getResultList();

		} catch (Exception e) {
			throw new SegmaException(e);
		}
	}
	
	public int rejectRole(String roleId, String appId, String userId) throws SegmaException {

		try {

			Query queryDeleteNewLst = getSession().createSQLQuery("DELETE APP_USER_ROLES " + " WHERE ROLE_ID = '"
					+ roleId + "' AND USER_ID ='" + userId + "' AND APP_ID ='" + appId + "'");

			if (queryDeleteNewLst.executeUpdate() == 1)
				return 1;
			else
				return 0;

		} catch (Exception e) {
			throw new SegmaException(e);
		}
	}

	
	public List<AppUserRoles> getAppUserRolesAgainstApplication(String systemId, String userId) throws SegmaException {

		try {

			CriteriaBuilder cb = em.getCriteriaBuilder();
			CriteriaQuery<AppUserRoles> cq = cb.createQuery(AppUserRoles.class);

			Root<AppUserRoles> branch = cq.from(AppUserRoles.class);
			Predicate activePredicate = cb.equal(branch.get("active"), Constants.SegmaStatus.ActiveUser);
			Predicate verifyStatusPredicate = cb.equal(branch.get("verSts"), Constants.SegmaMakerCheckerStatus.Approve);
			Predicate systemPredicate = cb.equal( branch.get("id").get("appId"), systemId);
			Predicate userIdPredicate = cb.equal( branch.get("id").get("userId"), userId);

			cq.where(activePredicate, verifyStatusPredicate,systemPredicate,userIdPredicate);
			cq.distinct(true);
			TypedQuery<AppUserRoles> appRolesTypedQuery = em.createQuery(cq);
			em.clear();
			em.close();

			List<AppUserRoles> appRoles= appRolesTypedQuery.getResultList();

			List<AppUserRoles> appRolesReturn = new ArrayList<AppUserRoles>();

			for (AppUserRoles appUserRolesObj : appRoles) {
				appRolesReturn.add(new AppUserRoles(
						new AppUserRolesId(appUserRolesObj.getId().getUserId(), appUserRolesObj.getId().getAppId(),
								appUserRolesObj.getId().getRoleId()),
						appUserRolesObj.getAppUsers(), appUserRolesObj.getAppSysRoles(), appUserRolesObj.getRemarks(),
						appUserRolesObj.getActive(), appUserRolesObj.getInputBy(), appUserRolesObj.getInputDate(),
						appUserRolesObj.getVerBy(), appUserRolesObj.getVerDate(), appUserRolesObj.getVerSts()));
			}
			for (AppUserRoles role : appRoles) {
				Hibernate.initialize(role.getAppSysRoles());

			}
			return appRoles;
		} catch (Exception e) {
			throw new SegmaException(e);
		}

	}

	
	public List<AppUserRoles> getAllInActiveUserRole(String userId) throws SegmaException {


		try {


			CriteriaBuilder cb = em.getCriteriaBuilder();
			CriteriaQuery<AppUserRoles> cq = cb.createQuery(AppUserRoles.class);

			Root<AppUserRoles> appUserRoles = cq.from(AppUserRoles.class);
			Predicate activePredicate = cb.notEqual(appUserRoles.get("verSts"), Constants.SegmaMakerCheckerStatus.Approve);
			Predicate statusPredicate = cb.equal(appUserRoles.get("inputBy"), userId);


			cq.where(activePredicate, statusPredicate);

			TypedQuery<AppUserRoles> query = em.createQuery(cq);
			em.clear();
			em.close();

			return query.getResultList();

		} catch (Exception e) {
			throw new SegmaException(e);
		}
	}


	public List<UserRolePicklistDto> getAppUserRolesDtoAgainstApplication(String systemId, String userId)
			throws SegmaException {

		try {
			Criteria criteria = getSession().createCriteria(AppUserRoles.class);
			criteria.add(Restrictions.eq("id.appId", systemId));
			criteria.add(Restrictions.eq("id.userId", userId));
			criteria.add(Restrictions.eq("active", Constants.SegmaActiveUser.ActiveUser));
			criteria.add(Restrictions.eq("verSts", Constants.SegmaMakerCheckerStatus.Approve));

			List<AppUserRoles> appRoles = criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();

			List<UserRolePicklistDto> userRolesTarget = new ArrayList<UserRolePicklistDto>();

			for (AppUserRoles appUserRoles : appRoles) {
				userRolesTarget.add(new UserRolePicklistDto(appUserRoles.getId().getAppId(),
						appUserRoles.getId().getRoleId(), appUserRoles.getAppSysRoles().getAppSystems().getAppName(),
						appUserRoles.getAppSysRoles().getRoleName()));
			}

			return userRolesTarget;
		} catch (Exception e) {
			throw new SegmaException(e);
		}

	}

}
