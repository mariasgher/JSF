
package com.segmadesk.dao.impl;

import java.io.Serializable;
import java.util.List;

import com.segmadesk.dao.IAppFunctionsHome;
import com.segmadesk.model.AppSysFunctions;
import com.segmadesk.util.SegmaException;

// Generated Jun 16, 2016 12:43:07 PM by Hibernate Tools 5.1.0.Alpha1

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;


@Repository("iAppFunctionsHome")
public class AppFunctionsHomeImpl extends AbstractDao implements Serializable, IAppFunctionsHome {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2458099510329763508L;
	private static final Log log = LogFactory.getLog(AppFunctionsHomeImpl.class);

	@Override
	public List<AppSysFunctions> getAllPages() throws SegmaException {

	
		try {
			
			Criteria criteria = getSession().createCriteria(AppSysFunctions.class);
			List<AppSysFunctions> appFunctions = criteria.list();

			return appFunctions;
		} catch (Exception e) {
			throw new SegmaException(e);
		}
	}
	
	

	@Override
	public AppSysFunctions findByPageId(java.lang.String id, String appId) throws SegmaException {
		
	

		try {
			Criteria criteria = getSession().createCriteria(AppSysFunctions.class);
			criteria.add( Restrictions.eq("id.pageId", id));
			criteria.add( Restrictions.eq("id.appId", appId));
			AppSysFunctions appFunctions = (AppSysFunctions) criteria.uniqueResult();

			return appFunctions;
		} catch (Exception e) {
			throw new SegmaException(e);
		} 
		
	}
}
