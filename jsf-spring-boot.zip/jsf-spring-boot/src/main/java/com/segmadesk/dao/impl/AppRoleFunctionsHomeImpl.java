package com.segmadesk.dao.impl;

import java.io.Serializable;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.segmadesk.dao.IAppRoleFunctionsHome;
import com.segmadesk.model.AppRoleFunctions;
import com.segmadesk.util.Constants;
import com.segmadesk.util.SegmaException;


@Repository("iAppRoleFunctionsHome")
public class AppRoleFunctionsHomeImpl extends AbstractDao implements IAppRoleFunctionsHome, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1518518378748879977L;

	@Override
	public List getAlreadyAddedPages(String roleId) throws SegmaException {

	
		try {
		

			Query query = getSession()
					.createSQLQuery("select PAGE_ID from  APP_ROLE_FUNCTIONS where ROLE_ID ='" + roleId
							+ "' and ACTIVE = '" + Constants.SegmaStatus.ActiveUser + "'");

			List result = query.list();

			return result;
		} catch (Exception e) {
			throw new SegmaException(e);
		} 

	}
	
	@Override
	public List getAllPages(String roleId, String appId) throws SegmaException {

	
		try {
	
			Criteria criteria = getSession().createCriteria(AppRoleFunctions.class)
			.add( Restrictions.eq("id.roleId", roleId)).add( Restrictions.eq("id.appId", appId));;
			Criterion  c1= Restrictions.eq("active", Constants.SegmaStatus.ActiveUser);
			Criterion  c2= Restrictions.eq("verSts", Constants.SegmaMakerCheckerStatus.NewUser);
			Criterion  c3= Restrictions.eq("active", Constants.SegmaStatus.InActive);
			
			criteria.add(Restrictions.or(Restrictions.and(c3, c2), c1));
			
			
			List<AppRoleFunctions> atmRolesPages = criteria.list();

			return atmRolesPages;
		} catch (Exception e) {
			throw new SegmaException(e);
		}
	}
	
	
	
	@Override
	public List getPickListPages(String roleId, String appId) throws SegmaException {

	
		try {
	
			Query query = getSession()
					.createSQLQuery("select PAGE_ID from  APP_ROLE_FUNCTIONS where ROLE_ID ='" + roleId + "' AND APP_ID ='" + appId
							+ "' and (ACTIVE = '" + Constants.SegmaStatus.Block + "'" + " AND VER_STS = '"+Constants.SegmaMakerCheckerStatus.EditUser+ "')" );

			List result = query.list();

			return result;
		} catch (Exception e) {
			throw new SegmaException(e);
		} 

	}


	@Override
	public List getAllRolePages() throws SegmaException {

	
		try {
	
			Criteria criteria = getSession().createCriteria(AppRoleFunctions.class);
			// criteria.add( Restrictions.eq("active",
			// AtmConstant.AtmActiveRoles.ActiveUser));

			List<AppRoleFunctions> atmRolesPages = criteria.list();

			return atmRolesPages;
		} catch (Exception e) {
			throw new SegmaException(e);
		} 
	}

	@Override
	public int blockRoleFunction(AppRoleFunctions roleFunctionObj, String userId) throws SegmaException {

	
		try {
		
			Query	updateRoleUserQuery  =  getSession().createSQLQuery("UPDATE APP_ROLE_FUNCTIONS"
					+" SET ACTIVE = '"+Constants.SegmaStatus.Block+"', "
					+ "STATUS = '"+Constants.SegmaMakerCheckerStatus.EditUser+"' "
					+ ",OLD_ACTIVE = '"+roleFunctionObj.getActive()+"', "
					+ "OLD_STATUS = '"+roleFunctionObj.getVerSts()+"' ,"
					+ " REMARKS = '"+roleFunctionObj.getRemarks()+"'  , INPUT_BY = '"+userId+"',INPUT_DATE = sysdate"
					+" WHERE PAGE_ID='"+roleFunctionObj.getAppSysFunctions().getId().getPageId()+"' AND ROLE_ID='"+roleFunctionObj.getId().getRoleId()+"'");
			int returnupdateVale = updateRoleUserQuery.executeUpdate();
		
			return 	returnupdateVale;

		} catch (Exception ex) {
		
			throw new SegmaException(ex);

		} 

	}
	
	
	@Override
	public AppRoleFunctions findByPageId(java.lang.String pageId , String roleId, String appId) throws SegmaException {
		
	

		try {
		
			Criteria criteria = getSession().createCriteria(AppRoleFunctions.class);
			criteria.add( Restrictions.eq("id.pageId", pageId));
			criteria.add( Restrictions.eq("id.roleId", roleId));
			criteria.add( Restrictions.eq("id.appId", appId));

			AppRoleFunctions appFunctions = (AppRoleFunctions) criteria.uniqueResult();

			return appFunctions;
		} catch (Exception e) {
			throw new SegmaException(e);
		} 
		
	}


}
