package com.segmadesk.dao.impl;
// Generated Jun 16, 2016 12:43:07 PM by Hibernate Tools 5.1.0.Alpha1

import java.io.Serializable;
import java.util.List;

import com.segmadesk.dao.IAppModulesHome;
import com.segmadesk.model.AppSysModules;
import com.segmadesk.util.SegmaException;

import org.hibernate.Criteria;
import org.springframework.stereotype.Repository;



@Repository("iAppModulesHome")
public class AppModulesHomeImpl extends AbstractDao implements Serializable, IAppModulesHome { 
	/**
	 * 
	 */
	private static final long serialVersionUID = -8993464589052426856L;

	@Override
	public List<AppSysModules> getAllModules() throws SegmaException {

	

		try {
			
			Criteria criteria = getSession().createCriteria(AppSysModules.class);
			List<AppSysModules> appModule = criteria.list();

			return appModule;
		} catch (Exception e) {
			throw new SegmaException(e);
		} 
	}
}
