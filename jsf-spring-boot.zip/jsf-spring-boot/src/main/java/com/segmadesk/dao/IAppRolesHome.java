package com.segmadesk.dao;

import java.util.List;

import com.segmadesk.dto.UserRolePicklistDto;
import com.segmadesk.model.AppSysRoles;
import com.segmadesk.util.SegmaException;

import org.hibernate.Session;

public interface IAppRolesHome {

	public List<AppSysRoles> getAllAppRoles() throws SegmaException;

	List<AppSysRoles> getRolesAgainstId(List<String> roleIds) throws SegmaException;

	List<AppSysRoles> getAllRoles() throws SegmaException;

	void blockRole(AppSysRoles roleBlockObj, String userId) throws SegmaException;

	int approve(AppSysRoles userApproveObj, String userId, String appId) throws SegmaException;

	void reject(AppSysRoles userApproveObj, String userId,String appId) throws SegmaException;

	List getSdmuRole(String userID, String roleId) throws SegmaException;


	List<AppSysRoles> getAllAppRolesAgainstApplication(String systemId) throws SegmaException;

	public List<UserRolePicklistDto> getAllAppRolesDtoAgainstApplication(String systemId) throws SegmaException;

	List<AppSysRoles> getRolesAgainstIds(List<String> roleIds) throws SegmaException;
}
