package com.segmadesk.dao.impl;
// Generated Jun 30, 2016 12:56:13 PM by Hibernate Tools 3.5.0.Final

import java.io.Serializable;
import java.math.BigInteger;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import com.segmadesk.dao.AppUsersLoginHome;
import com.segmadesk.dto.StoreProcedureReturn;
import com.segmadesk.dto.ThreeColumnsMapper;
import com.segmadesk.dto.UserRolesApplications;
import com.segmadesk.dto.oneColumnsMapper;
import com.segmadesk.model.AppUserRoles;
import com.segmadesk.model.AppUserRolesId;
import com.segmadesk.model.AppUsers;
import com.segmadesk.util.Constants;
import com.segmadesk.util.SegmaException;

// Generated Jun 16, 2016 12:43:07 PM by Hibernate Tools 5.1.0.Alpha1

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Criteria;
import org.hibernate.Hibernate;
import org.hibernate.Query;
import org.hibernate.criterion.Restrictions;
import org.hibernate.jdbc.Work;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;


@Repository
public class AppUsersLoginHomeImpl extends AbstractDao implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8423916792542885132L;

	private static final Log log = LogFactory.getLog(AppUsersLoginHomeImpl.class);

	@Autowired
	JdbcTemplate jdbcTemplate;

	@Autowired
	EntityManager em;

	public StoreProcedureReturn firstTimeLogin(String userName, String password) throws SegmaException, SQLException {

		log.debug("firstTimeLogin");

		final StoreProcedureReturn procedureReturn = new StoreProcedureReturn();

		// Connection dbConnection = session.connection();
		try {
			getSession().doWork(new Work() {
				public void execute(Connection dbConnection) throws SQLException {
					CallableStatement callableStatement = null;
					try {

						String getDBUSERByUserIdSql = "{call APP_PERFORMLOGIN(?,?,?,?)}";
						callableStatement = dbConnection.prepareCall(getDBUSERByUserIdSql);

						callableStatement.setString(1, userName);
						callableStatement.setString(2, password);
						callableStatement.registerOutParameter(3, java.sql.Types.VARCHAR);
						callableStatement.registerOutParameter(4, java.sql.Types.VARCHAR);

						// execute getDBUSERByUserId store procedure
						callableStatement.executeUpdate();

						String flag = callableStatement.getString(3).trim();// set flag
						String desc = callableStatement.getString(4).trim();// set description

						procedureReturn.setStatus(flag);
						procedureReturn.setDescription(desc);

					} catch (SQLException e) {
						e.printStackTrace();
					} finally {

						if (callableStatement != null) {
							callableStatement.close();
						}
						if (dbConnection != null) {
							dbConnection.close();
						}

					}
				}
			});
		} catch (Exception e) {
			throw new SegmaException(e);
		}
		return procedureReturn;

	}

	public AppUsers getAppUsers(String userid) throws SegmaException {

		try {
			log.debug("getAtmUsers");

			Criteria criteria = getSession().createCriteria(AppUsers.class);
			criteria.add(Restrictions.eq("userid", userid));
			criteria.add(Restrictions.eq("active", Constants.SegmaStatus.ActiveUser));

			AppUsers segmaUsers = (AppUsers) criteria.uniqueResult();
			Hibernate.initialize(segmaUsers.getAppUserRoleses());
			for (AppUserRoles segmaUsers1 : segmaUsers.getAppUserRoleses()) {

				Hibernate.initialize(segmaUsers1.getAppSysRoles());

			}

			return segmaUsers;
		} catch (Exception e) {
			throw new SegmaException(e);
		}

	}

	public String encryptPassword(String password) throws SegmaException {

		return "Encrypt";

	}

	public List<AppUsers> rejUsers(String userId) throws SegmaException {

		CriteriaBuilder cb = em.getCriteriaBuilder();
		CriteriaQuery<AppUsers> cq = cb.createQuery(AppUsers.class);

		Root<AppUsers> user = cq.from(AppUsers.class);
		Predicate activePredicate = cb.equal(user.get("verSts"), Constants.SegmaMakerCheckerStatus.Reject);
		Predicate statusPredicate = cb.equal(user.get("verBy"), userId);

		cq.where(activePredicate, statusPredicate);

		TypedQuery<AppUsers> query = em.createQuery(cq);
		em.clear();
		em.close();

		return query.getResultList();

	}

	public List<AppUsers> allUsers() throws SegmaException {

		CriteriaBuilder cb = em.getCriteriaBuilder();
		CriteriaQuery<AppUsers> cq = cb.createQuery(AppUsers.class);

		Root<AppUsers> user = cq.from(AppUsers.class);

		cq.select(user);

		TypedQuery<AppUsers> query = em.createQuery(cq);
		em.clear();
		em.close();

		return query.getResultList();

	}

	public List<AppUsers> getUsersNotCreatedBy(String userid) throws SegmaException {

		try {

			CriteriaBuilder cb = em.getCriteriaBuilder();
			CriteriaQuery<AppUsers> cq = cb.createQuery(AppUsers.class);

			Root<AppUsers> user = cq.from(AppUsers.class);
			Predicate activePredicate = cb.equal(user.get("verSts"), Constants.SegmaMakerCheckerStatus.Approve);
			Predicate statusPredicate = cb.equal(user.get("active"), Constants.SegmaActiveUser.ActiveUser);

			cq.where(activePredicate, statusPredicate);

			cq.distinct(true);
			TypedQuery<AppUsers> query = em.createQuery(cq);
			List<AppUsers> ubpsUserslst = query.getResultList();

			// criteria.add(orExp);

			List<AppUsers> returnedUserList = new ArrayList<AppUsers>();
			;
			for (AppUsers appUsers : ubpsUserslst) {
				Set<AppUserRoles> appUsersRolesSet = new HashSet<>();
				for (AppUserRoles appUsersRoles : appUsers.getAppUserRoleses()) {
					AppUserRoles appUsersRolesObj = new AppUserRoles(
							new AppUserRolesId(appUsersRoles.getAppUsers().getUserid(),
									appUsersRoles.getAppSysRoles().getId().getAppId(),
									appUsersRoles.getId().getRoleId()),
							appUsersRoles.getAppUsers(), appUsersRoles.getAppSysRoles(), appUsersRoles.getRemarks(),
							appUsersRoles.getActive(), appUsersRoles.getInputBy(), appUsersRoles.getInputDate(),
							appUsersRoles.getVerBy(), appUsersRoles.getVerDate(), appUsersRoles.getVerSts());
					appUsersRolesSet.add(appUsersRolesObj);
				}

				AppUsers appUsersObj = new AppUsers(appUsers.getUserid(),
						appUsers.getUsername(), appUsers.getContactNo(),
						appUsers.getCnic(), appUsers.getEmail(), appUsers.getActive(), appUsers.getPasswd(),
						appUsers.getInputBy(),  appUsers.getInputDate(), appUsers.getVerBy(), appUsers.getVerDate(),
						appUsers.getVerSts(), appUsers.getStatus(),appUsers.getUserStsDet(), appUsers.getMaxTry(), appUsers.getLockTime(),
						appUsers.getOldStatus(), appUsers.getRemarks(), appUsers.getPwdResetDate(),
						appUsers.getOldActive(), appUsers.getOldVerSts(), appUsersRolesSet);
				returnedUserList.add(appUsersObj);
			}
			
			em.clear();
			em.close();
			return returnedUserList;
		} catch (Exception e) {
			throw new SegmaException(e);
		}

	}

	public StoreProcedureReturn ChangePassword(String username, String password, String oldPassword)
			throws SQLException, SegmaException {

		final StoreProcedureReturn procedureReturn = new StoreProcedureReturn();

		try {
			getSession().doWork(new Work() {
				public void execute(Connection dbConnection) throws SQLException {
					CallableStatement callableStatement = null;
					try {
						String getDBUSERByUserIdSql = "{call APP_RESET_PWD(?,?,?,?,?)}";
						callableStatement = dbConnection.prepareCall(getDBUSERByUserIdSql);

						callableStatement.setString(1, username);
						callableStatement.setString(2, password);
						callableStatement.setString(3, oldPassword);
						callableStatement.registerOutParameter(4, java.sql.Types.CHAR);
						callableStatement.registerOutParameter(5, java.sql.Types.VARCHAR);

						// execute getDBUSERByUserId store procedure
						callableStatement.executeUpdate();

						String flag = callableStatement.getString(4);// set flag for description
						String description = callableStatement.getString(5);// set flag for description
						procedureReturn.setDescription(description);
						procedureReturn.setStatus(flag);

						if (flag.contains("L")) {
							// procedureReturn.setDescription(" Password Length Must between 7 and 12 ");
							// procedureReturn.setStatus("L");
						} else if (flag.contains("R")) {
							procedureReturn.setDescription(
									" Passwords should contain 3 of the character types: lowercase letters: a-z; Special character: $,_ ;  numbers: 0-9.Please choose a different one");
							procedureReturn.setStatus("R");
						} else if (flag.contains("S")) {

							procedureReturn.setDescription(" Your Password Changed Successfully ");
							procedureReturn.setStatus("S");
						}
					} catch (SQLException e) {
						e.printStackTrace();
					} finally {

						if (callableStatement != null) {
							callableStatement.close();
						}
						if (dbConnection != null) {
							dbConnection.close();
						}

					}
				}
			});

		} catch (Exception e) {
			throw new SegmaException(e);
		}

		return procedureReturn;

	}



	public StoreProcedureReturn SendEmail(String userId, String callFlag) throws SQLException, SegmaException {

		final StoreProcedureReturn procedureReturn = new StoreProcedureReturn();

		try {

			getSession().doWork(new Work() {
				public void execute(Connection dbConnection) throws SQLException {
					CallableStatement callableStatement = null;

					try {
						String getDBUSERByUserIdSql = "{call APP_RESETPWD_REQ(?,?,?,?,?)}";
						callableStatement = dbConnection.prepareCall(getDBUSERByUserIdSql);

						callableStatement.setString(1, userId);
						callableStatement.setString(2, callFlag);
						callableStatement.setString(3, Constants.ApplicationName.APPLICATION_NAME);

						callableStatement.registerOutParameter(4, java.sql.Types.VARCHAR);

						callableStatement.registerOutParameter(5, java.sql.Types.VARCHAR);

						// execute getDBUSERByUserId store procedure
						callableStatement.executeUpdate();

						procedureReturn.setStatus(callableStatement.getString(4));
						procedureReturn.setDescription(callableStatement.getString(5));// set flag for description
					} catch (SQLException e) {
						e.printStackTrace();
					} finally {

						if (callableStatement != null) {
							callableStatement.close();
						}
						if (dbConnection != null) {
							dbConnection.close();
						}

					}
				}
			});

		} catch (Exception e) {
			throw new SegmaException(e);
		}

		return procedureReturn;

	}

	public static void main(String[] args) {
		try {

			new AppUsersLoginHomeImpl().SendEmail("E001", "N");
		} catch (SQLException | SegmaException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public List<AppUsers> pendingUsers(String userId) throws SegmaException {

		try {

			CriteriaBuilder cb = em.getCriteriaBuilder();
			CriteriaQuery<AppUsers> cq = cb.createQuery(AppUsers.class);

			Root<AppUsers> user = cq.from(AppUsers.class);
			Predicate inactivePred = cb.equal(user.get("active"), Constants.SegmaStatus.InActive);
			Predicate blockPred = cb.equal(user.get("active"), Constants.SegmaStatus.Block);
			Predicate updateVerfyStatusPred = cb.equal(user.get("verSts"), Constants.SegmaMakerCheckerStatus.Updated);
			Predicate editUserPred = cb.equal(user.get("verSts"), Constants.SegmaMakerCheckerStatus.EditUser);
			Predicate newUserPred = cb.equal(user.get("verSts"), Constants.SegmaMakerCheckerStatus.NewUser);
			Predicate inputPredicate = cb.notEqual(user.get("inputBy"), userId);

			Predicate orEpression = cb.or(inactivePred, blockPred);
			Predicate andExp = cb.or(
					cb.or(cb.and(updateVerfyStatusPred, inputPredicate), cb.and(newUserPred, inputPredicate)),
					cb.and(editUserPred, inputPredicate));

			cq.where(orEpression, andExp);

			cq.distinct(true);
			TypedQuery<AppUsers> query = em.createQuery(cq);
			List<AppUsers> ubpsUsers = query.getResultList();

		for (AppUsers appUsers : ubpsUsers) {
				Set<AppUserRoles> appRolesSet = new HashSet<>();
				for (AppUserRoles appUserRoles : appUsers.getAppUserRoleses()) {
					appRolesSet.add(appUserRoles);

				}
				appUsers.setAppUserRoleses(appRolesSet);
			}

			return ubpsUsers;
		} catch (Exception e) {
			throw new SegmaException(e);
		}
	}

	public boolean isUsernameExist(String username) throws SegmaException {

		try {

			CriteriaBuilder cb = em.getCriteriaBuilder();
			CriteriaQuery<AppUsers> cq = cb.createQuery(AppUsers.class);

			Root<AppUsers> user = cq.from(AppUsers.class);
			Predicate empPred = cb.equal(user.get("username"), username);

			cq.where(empPred);
			TypedQuery<AppUsers> query = em.createQuery(cq);
			return query.getResultList().isEmpty() ? false : true;

		} catch (Exception e) {
			throw new SegmaException(e);
		}
	}

	public int blockUser(AppUsers userEditObj, String userId) throws SegmaException {

		try {
			String sql = "";
			sql += " UPDATE APP_USERS ";
			sql += " SET ACTIVE = '" + Constants.SegmaStatus.Block + "',";
			sql += " VER_STS = '" + Constants.SegmaMakerCheckerStatus.EditUser + "',";
			sql += " OLD_ACTIVE = '" + userEditObj.getActive() + "',";
			sql += " OLD_VER_STS = '" + userEditObj.getVerSts() + "',";
			sql += " REMARKS = 'GGG',";
			sql += " INPUT_BY = '" + userId + "',";
			sql += " INPUT_DATE = SYSDATE ";
			sql += " WHERE USERID = '" + userEditObj.getUserid() + "'";
			return jdbcTemplate.update(sql);

		} catch (Exception ex) {

			throw new SegmaException(ex);

		}

	}

	public List<UserRolesApplications> getApplicationName(String username) throws SegmaException {
		String sql = "SELECT DISTINCT(APPSYTEM.APP_ID), APUSERROLE.USER_ID, APPSYTEM.APP_URL ,APPSYTEM.APP_DESCRIPTION,APPSYTEM.ACTIVE,APPSYTEM.VER_STS FROM APP_USER_ROLES APUSERROLE, APP_SYSTEMS APPSYTEM WHERE  APUSERROLE.APP_ID=APPSYTEM.APP_ID AND  APUSERROLE.USER_ID='"
				+ username + "'";
		return jdbcTemplate.query(sql, new ThreeColumnsMapper());

	}

	public List<String> getRoles(String username, int check) throws SegmaException {
		if (1 == check) {
			String sql = "SELECT APUSERROLE.USER_ID FROM APP_USER_ROLES APUSERROLE WHERE apUserRole.ROLE_ID='"
					+ Constants.ADD_USER_AUTHORITY + "' AND  apUserRole.USER_ID='" + username + "'";
			return jdbcTemplate.query(sql, new oneColumnsMapper());
		} else {
			String sql = "SELECT APUSERROLE.USER_ID FROM APP_USER_ROLES APUSERROLE WHERE (apUserRole.ROLE_ID='"
					+ Constants.StaticStatus.Static_Inputter + "' OR apUserRole.ROLE_ID='"
					+ Constants.StaticStatus.Static_Approver + "')  AND  apUserRole.USER_ID='" + username + "'";
			return jdbcTemplate.query(sql, new oneColumnsMapper());
		}
	}

}
