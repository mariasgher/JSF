package com;

import java.util.Date;
import java.util.Locale;

import javax.faces.webapp.FacesServlet;
import javax.servlet.ServletContext;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.CustomScopeConfigurer;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.web.context.ServletContextAware;

import com.google.common.collect.ImmutableMap;
import com.segmadesk.mb.ViewScope;



@ServletComponentScan
@SpringBootApplication
public class JsfSpringBootApplication extends SpringBootServletInitializer implements ServletContextAware  {

	@Autowired
	private Environment env;
	
	public static void main(String[] args) {
		SpringApplication.run(JsfSpringBootApplication.class, args);
	}

	@Bean
	public static CustomScopeConfigurer viewScope() {
		CustomScopeConfigurer configurer = new CustomScopeConfigurer();
		configurer.setScopes(new ImmutableMap.Builder<String, Object>().put("view", new ViewScope()).build());
		return configurer;
	}

	@Bean
	public ServletRegistrationBean<FacesServlet> servletRegistrationBean() {
		ServletRegistrationBean<FacesServlet> servletRegistrationBean = new ServletRegistrationBean<>(
				new FacesServlet(), "*.xhtml");
		servletRegistrationBean.setLoadOnStartup(1);
		
		return servletRegistrationBean;
	}

	@Override
	public void setServletContext(ServletContext servletContext) {
		servletContext.setInitParameter("com.sun.faces.forceLoadConfiguration", Boolean.TRUE.toString());
		//servletContext.setInitParameter("org.apache.myfaces.AUTOMATIC_EXTENSIONLESS_MAPPING", Boolean.TRUE.toString());
		servletContext.setInitParameter("javax.faces.FACELETS_SKIP_COMMENTS", "true");
	//	servletContext.addListener("org.springframework.web.context.ContextLoaderListener");
	//	servletContext.setInitParameter("com.ocpsoft.pretty.BASE_PACKAGES", "foundation");
	}

	@Bean
		public DataSource dataSource() {
			System.out.println(new Date()+": in datasource");
			DriverManagerDataSource dataSource = new DriverManagerDataSource();
			Locale.setDefault(Locale.ENGLISH); // use this for change NLS
			dataSource.setDriverClassName(env.getRequiredProperty("jdbc.driverClassName"));
			dataSource.setUrl(env.getRequiredProperty("jdbc.url"));
			dataSource.setUsername(env.getRequiredProperty("jdbc.username"));
			dataSource.setPassword(env.getRequiredProperty("jdbc.password"));
			dataSource.setSchema(env.getRequiredProperty("jdbc.schema"));
			return dataSource;
		}
	

	
}
