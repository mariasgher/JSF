
function resetUserForm() {
	document.getElementById('addForm:firstName').value = '';
	document.getElementById('addForm:lastName').value = '';
	document.getElementById('addForm:userName').value = '';
	document.getElementById('addForm:password').value = '';
	document.getElementById('addForm:email').value = '';
	document.getElementById('addForm:msgAdd').value = '';

}

function resetGroupForm() {
	document.getElementById('formAdd:name').value = '';
	document.getElementById('formAdd:description').value = '';
	document.getElementById('formAdd:msgAdd').value = '';
}

var last_row = null;
function rowSelected(row) {
	if (last_row != null && last_row != row) {
		if (last_row.rowIndex % 2 == 0)
			last_row.style.background = '#D0E6E0';
		else
			last_row.style.background = '#85bdd2';
	}
	//	last_row = row;
	//	row.style.background = '#91cf37';
}

var flag = 0;
function changeImg(img_name, img_src) {
	if (flag == 0) {
		img_name.src = img_src;
	}
}

function changeButtonImage(obj) {
	// Normal Images Array

	var imagesArray = new Array("servermanagement.png",
			"connectionbrokering.png", "usermanagement.png",
			"groupmanagement.png", "support.png");
	var ids = new Array("servermanagement", "connectionbrokering",
			"usermanagement", "groupmanagement", "supportmanagement");

	for ( var i = 0; i < imagesArray.length; i++) {

		// alert(imagesArray[i].substring(0,imagesArray[i].lastIndexOf(".")));

		document.getElementById("form1:" + ids[i]).src = "../images/"
			+ imagesArray[i];

	}
	// finally setting the source of required image to hover image
	document.getElementById(obj.id).src = "../images/" + obj.id
	+ "hover.png";
}


function rotate() {
	//  angle+=1;
	
	$("#imageCpuDail").rotate((document.getElementById("pollServer:countCpu").innerHTML) * 3);
	//	$("#imageMemoryDail").rotate(eventMemoryDail * 3);
}

function rotate1() {
	
	//  angle+=1;
	//	$("#imageCpuDail").rotate(eventCpuDail * 3);
	$("#imageMemoryDail").rotate((document.getElementById("pollServer:countMem").innerHTML) * 3);
}

function messageTimeout() {

	setTimeout(function() {
		//document.getElementById('form1:msg').innerHTML="";


		$(".messageText").fadeOut(2000);

		//alert("12");
	}, 10000);
}

function resetValues() {
	document.getElementById('vmAddForm:vmName').value = '';
	document.getElementById('vmAddForm:vmAddMsg').value = '';
	document.getElementById('vmAddForm:vmGroupsNumber').selectedIndex = 0;
	document.getElementById('vmAddForm:tempalteGroupsNumber').selectedIndex = 0;
}
function creatingCPUGraph(eventCpuDail) {
	
	g_graph = new Graph({
		'id' : "cpuGraph",
		'showshadow' : true,

		'strokeStyle' : "#819C58",
		'fillStyle' : "rgba(64,128,0,0.25)",
		'showdots' : false,
		'background' : "#404040",
		'lineWidth' : 2,
		'showfill' : false,
		'strokeStyle' : "#ff5555",
		'showlabels' : false,
		'gridcolor' : "#cfcfcf",
		'range' : [ 0, 100 ],
		'data' : values(eventCpuDail)
	});
};
function values(eventDail) {
	
	var result = eventDail.split("||");
	return result;
}
function creatingMemGraph(eventCpuDail) {
	
	g_graph = new Graph({
		'id' : "memoryGraph",
		'showshadow' : true,

		'strokeStyle' : "#819C58",
		'fillStyle' : "rgba(64,128,0,0.25)",
		'showdots' : false,
		'background' : "#404040",
		'lineWidth' : 2,
		'showfill' : false,
		'strokeStyle' : "#ff5555",
		'showlabels' : false,
		'gridcolor' : "#cfcfcf",
		'range' : [ 0, 100 ],
		'data' : values(eventCpuDail)
	});
};


function someaction(event){

}

